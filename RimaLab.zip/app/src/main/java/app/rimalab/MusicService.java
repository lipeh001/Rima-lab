package app.rimalab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;

/** Notificação do beat: mantém o app vivo em segundo plano e tem o botão de pausar/tocar. */
public class MusicService extends Service {
    static final String CH = "rimalab_player";
    static final String A_PLAY = "app.rimalab.PLAY", A_PAUSE = "app.rimalab.PAUSE", A_STOP = "app.rimalab.STOP";
    static final int ID = 7;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        String a = in == null ? null : in.getAction();
        if (A_PLAY.equals(a)) { MainActivity.remote("play"); return START_NOT_STICKY; }
        if (A_PAUSE.equals(a)) { MainActivity.remote("pause"); return START_NOT_STICKY; }
        if (A_STOP.equals(a)) {
            MainActivity.remote("pause");
            stopForeground(true); stopSelf();
            return START_NOT_STICKY;
        }
        boolean playing = in != null && in.getIntExtra("st", 0) == 1;
        String title = in != null ? in.getStringExtra("title") : null;
        if (title == null || title.length() == 0) title = "Rima Lab";
        Notification n = build(playing, title);
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(ID, n);
        return START_NOT_STICKY;
    }

    private PendingIntent act(String action, int code) {
        Intent i = new Intent(this, MusicService.class).setAction(action);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification build(boolean playing, String title) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel c = new NotificationChannel(CH, "Beat tocando", NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action main = new Notification.Action.Builder(
                Icon.createWithResource(this, playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                playing ? "Pausar" : "Tocar", act(playing ? A_PAUSE : A_PLAY, 1)).build();
        Notification.Action close = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "Fechar", act(A_STOP, 2)).build();
        return new Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(playing ? "Tocando" : "Pausado")
                .setContentIntent(pi)
                .setOnlyAlertOnce(true)
                .setOngoing(playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(main).addAction(close)
                .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0))
                .build();
    }
}
