package app.rimalab;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    // Endereço https "de mentira" usado só como origem da página. É isso que faz o
    // YouTube aceitar o player (ele recusa páginas sem origem/referrer, erro 153).
    private static final String BASE = "https://rima-lab.app/";
    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#07051F"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setLoadWithOverviewMode(true);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                // links externos (fora do app e do player do YouTube) abrem no navegador
                if (u.startsWith(BASE) || u.contains("youtube.com") || u.contains("youtube-nocookie.com")
                        || u.contains("google.com") || u.contains("gstatic.com") || u.contains("ytimg.com")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) {}
                return true;
            }
        });

        try {
            InputStream in = getAssets().open("rima-lab.html");
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            in.close();
            web.loadDataWithBaseURL(BASE, o.toString("UTF-8"), "text/html", "UTF-8", null);
        } catch (Exception e) {
            web.loadData("Erro ao abrir o app: " + e, "text/plain", "UTF-8");
        }
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }
    @Override protected void onPause() { super.onPause(); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
