package app.rimalab;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    // Origem https neutra para a página (o widget do SoundCloud não exige origem específica).
    private static final String BASE = "https://appassets.androidplatform.net/";
    private WebView web;
    private PermissionRequest pendingMic;

    // Baixa a forma de onda do SoundCloud (só hosts do SoundCloud) e devolve o texto para a página
    private class Bridge {
        @JavascriptInterface public void fetchText(final String url, final String id) {
            new Thread(new Runnable() { @Override public void run() {
                String out = null;
                try {
                    Uri u = Uri.parse(url);
                    String h = u.getHost() == null ? "" : u.getHost();
                    if ("https".equals(u.getScheme()) && (h.endsWith("sndcdn.com") || h.endsWith("soundcloud.com"))) {
                        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                        c.setConnectTimeout(5000); c.setReadTimeout(5000);
                        if (c.getResponseCode() == 200) {
                            InputStream in = c.getInputStream();
                            ByteArrayOutputStream o = new ByteArrayOutputStream();
                            byte[] buf = new byte[8192]; int n;
                            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                            in.close();
                            out = o.toString("UTF-8");
                        }
                        c.disconnect();
                    }
                } catch (Exception e) {}
                final String js = "window.__zf(" + org.json.JSONObject.quote(id) + "," + (out == null ? "null" : org.json.JSONObject.quote(out)) + ")";
                web.post(new Runnable() { @Override public void run() { web.evaluateJavascript(js, null); } });
            }}).start();
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#07051F"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setLoadWithOverviewMode(true);
        android.webkit.CookieManager.getInstance().setAcceptCookie(true);
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "RimaNative");
        web.setWebChromeClient(new WebChromeClient() {
            // Microfone da calibragem: pede a permissão do Android e libera para a página
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    boolean mic = false;
                    for (String r : req.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) mic = true;
                    if (!mic) { req.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        if (pendingMic != null) pendingMic.deny();
                        pendingMic = req;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 77);
                    }
                }});
            }
        });
        web.setWebViewClient(new WebViewClient() {
            // Beats embutidos: a página pede https://appassets.androidplatform.net/beats/NOME.mp3 e o app entrega o arquivo da pasta assets/beats
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u != null && "appassets.androidplatform.net".equals(u.getHost()) && u.getPath() != null
                        && u.getPath().startsWith("/beats/") && !u.getPath().contains("..")) {
                    Map<String, String> h = new HashMap<String, String>();
                    h.put("Access-Control-Allow-Origin", "*");
                    try {
                        String path = u.getPath().substring(1);
                        InputStream in = getAssets().open(path);
                        String mime = path.endsWith(".json") ? "application/json" : path.endsWith(".ogg") ? "audio/ogg" : path.endsWith(".wav") ? "audio/wav" : "audio/mpeg";
                        return new WebResourceResponse(mime, null, 200, "OK", h, in);
                    } catch (Exception e) {
                        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(v, r);
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                // só intercepta navegação da página principal; o player (iframe) carrega livre
                if (!r.isForMainFrame()) return false;
                String u = r.getUrl().toString();
                if (u.startsWith(BASE) || u.contains("soundcloud.com") || u.contains("sndcdn.com")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) {}
                return true;
            }
        });

        try {
            InputStream in = getAssets().open("rima-lab.html");
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            in.close();
            web.loadDataWithBaseURL(BASE, o.toString("UTF-8"), "text/html", "UTF-8", null);
        } catch (Exception e) {
            web.loadData("Erro ao abrir o app: " + e, "text/plain", "UTF-8");
        }
    }

    // Botão voltar do Android: primeiro volta dentro do app (tela de treino/batalha); só minimiza se não houver pra onde voltar.
    @Override public void onBackPressed() {
        if (web == null) { moveTaskToBack(true); return; }
        web.evaluateJavascript("(function(){try{return window.rimaBack?rimaBack():false}catch(e){return false}})()", new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) { if (!"true".equals(v)) moveTaskToBack(true); }
        });
    }
    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 77 && pendingMic != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) pendingMic.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else pendingMic.deny();
            pendingMic = null;
        }
    }
    @Override protected void onPause() { super.onPause(); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
