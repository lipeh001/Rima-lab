/* Testa a composição real do Worker usado pelo analisador sem depender do navegador Android. */
const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('app/src/main/assets/rima-lab.html', 'utf8');
const a = html.indexOf('/*ANALYZER_START*/') + '/*ANALYZER_START*/'.length;
const b = html.indexOf('/*ANALYZER_END*/', a);
if (a < 0 || b < 0) throw new Error('Bloco do analisador não encontrado');
const analyzer = html.slice(a, b);
const mono = html.match(/const zMono=b=>\{[\s\S]*?\};/);
const workerFn = html.match(/function zAnalyzeAsync\(buf,hint,done\)\{[\s\S]*?\nfunction zLocLoad/);
if (!mono || !workerFn) throw new Error('Funções de análise assíncrona não encontradas');
const fn = workerFn[0].slice(0, workerFn[0].lastIndexOf('\nfunction zLocLoad'));
const blobs = new Map(); let blobId = 0;
class FakeBlob { constructor(parts) { this.source = parts.join(''); } }
const FakeURL = {
  createObjectURL(blob) { const u = 'blob:test-' + (++blobId); blobs.set(u, blob.source); return u; },
  revokeObjectURL(u) { blobs.delete(u); }
};
class FakeWorker {
  constructor(url) { this.source = blobs.get(url); this.terminated = false; }
  postMessage(data) {
    setImmediate(() => {
      if (this.terminated) return;
      const self = { postMessage: value => this.onmessage && this.onmessage({ data: value }) };
      try { vm.runInNewContext(this.source, { self, Float32Array, Float64Array, Uint16Array, Math, Array, Number, Object, isFinite, Error }); self.onmessage({ data }); }
      catch (e) { if (this.onerror) this.onerror(e); }
    });
  }
  terminate() { this.terminated = true; }
}
const context = vm.createContext({
  Float32Array, Float64Array, Uint16Array, Math, Array, Number, Object, isFinite,
  Worker: FakeWorker, Blob: FakeBlob, URL: FakeURL,
  setTimeout, clearTimeout, console
});
vm.runInContext(analyzer + '\n' + mono[0] + '\n' + fn + '\nglobalThis.runWorker=zAnalyzeAsync;', context);
const sr = 22050, seconds = 22, data = new Float32Array(sr * seconds);
// Beat sintético com kick em quatro tempos e caixa nos tempos 2 e 4.
for (let t = 0, bar = 0; t < seconds; t += 60 / 94, bar++) {
  const offset = Math.floor(t * sr), kick = (bar % 4 === 0 || bar % 4 === 2), amp = kick ? .85 : .55;
  for (let n = 0; n < Math.floor(sr * .085) && offset + n < data.length; n++) {
    const env = Math.exp(-n / (sr * .025));
    data[offset + n] += amp * env * (Math.sin(2 * Math.PI * (kick ? 72 : 180) * n / sr) + .15 * Math.sin(2 * Math.PI * 350 * n / sr));
  }
}
const buffer = { length: data.length, numberOfChannels: 1, sampleRate: sr, getChannelData: () => data };
let finished = false;
new Promise(resolve => context.runWorker(buffer, 94, value => { finished = true; resolve(value); })).then(result => {
  if (!finished) throw new Error('Worker não respondeu');
  console.log('OK Worker respondeu sem bloquear o fluxo principal:', result ? `BPM ${result.bpm}` : 'sem medição confiável; grade provisória permanece ativa');
}).catch(error => { console.error(error); process.exitCode = 1; });
