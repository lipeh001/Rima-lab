/* Teste isolado do sorteio Jamendo: carrega categorias pendentes e sorteia entre os três estilos. */
const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('app/src/main/assets/rima-lab.html', 'utf8');
function block(name, nextName) {
  const a = html.indexOf(`function ${name}(){`);
  const b = html.indexOf(`\nfunction ${nextName}(){`, a);
  if (a < 0 || b < 0) throw new Error(`Não encontrei ${name}/${nextName}`);
  return html.slice(a, b);
}
const source = block('zMixPick', 'zMixCheck') + '\n' + html.slice(html.indexOf('function zMixCheck(){'), html.indexOf('\n/* ----', html.indexOf('function zMixCheck(){')));
function makeSandbox(randomValue = 0) {
  const picked = { style: '', index: -1 };
  const requested = [];
  const sandbox = {
    ZLIB: {
      'Boom bap': [92, [['audio-b', 'Boom bap test', 92, 0, 'b-1', 'Boom bap']]],
      Trap: [140, [['audio-t', 'Trap test', 140, 0, 't-1', 'Trap']]],
      Drill: [142, [['audio-d', 'Drill test', 142, 0, 'd-1', 'Drill']]],
    },
    ZJS: { 'Boom bap': 'ok', Trap: undefined, Drill: undefined },
    ZS: { key: '' },
    ZMixWait: 0,
    Math: { random: () => randomValue, floor: Math.floor },
    zKey: x => 'jm-' + x[4],
    zJm: st => { requested.push(st); sandbox.ZJS[st] = 'load'; },
    zLS: st => { picked.style = st; },
    zLP: (i, auto, style) => { picked.style = style; picked.index = i; },
    zFlash: () => {},
  };
  return { sandbox, picked, requested };
}
const tests = [];
// Random values select each of the three style partitions in order.
for (const [random, expected] of [[0.01, 'Boom bap'], [0.4, 'Trap'], [0.8, 'Drill']]) {
  const { sandbox, picked } = makeSandbox(random);
  sandbox.ZJS = { 'Boom bap': 'ok', Trap: 'ok', Drill: 'ok' };
  vm.runInNewContext(source, sandbox);
  sandbox.zMixPick();
  tests.push([`sorteia ${expected}`, picked.style === expected]);
}
// A cross-style draw starts the missing genre requests and waits until all three finish.
{
  const { sandbox, picked, requested } = makeSandbox(0.8);
  vm.runInNewContext(source, sandbox);
  sandbox.zMixPick();
  const started = sandbox.ZMixWait === 1 && requested.includes('Trap') && requested.includes('Drill');
  sandbox.ZJS.Trap = 'ok';
  sandbox.ZJS.Drill = 'ok';
  sandbox.zMixCheck();
  tests.push(['aguarda estilos pendentes antes de sortear', started && sandbox.ZMixWait === 0 && picked.style === 'Drill']);
}
let failed = 0;
for (const [name, ok] of tests) { console.log((ok ? 'OK  ' : 'FAIL ') + name); if (!ok) failed++; }
console.log(`${tests.length - failed}/${tests.length} testes do sorteio passaram`);
process.exit(failed ? 1 : 0);
