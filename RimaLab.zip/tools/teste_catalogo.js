/* Regressão do catálogo: migração do cache antigo, fallback offline e aceitação de streams. */
const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('app/src/main/assets/rima-lab.html', 'utf8');
const checks = [];
const ok = (name, value) => checks.push([name, !!value]);

ok('não existe botão de sorteio entre gêneros', !html.includes('Sortear beat entre Boom bap, Trap e Drill'));
ok('não existem funções antigas de sorteio cruzado', !html.includes('function zMixPick()') && !html.includes('function zMixCheck()'));
ok('mantém as três abas de categoria', html.includes("Object.keys(ZLIB).map(s=>`<button class=\"tag chip"));
ok('lista permanece montada pelo cache mesmo offline', /function zBuild\(st\)\{const L=\(ZRAW\[st\]\|\|\[\]\)\.slice\(\)/.test(html));
ok('cache com menos de 50 faixas volta a consultar o Jamendo', /rows>=50&&Date\.now\(\)/.test(html));
ok('resultado de streaming não depende de link de download', /r&&r\.id&&r\.audio&&\(!r\.duration\|\|\(\+r\.duration\)>=60/.test(html));
ok('download offline só aparece com autorização explícita', html.includes('r.audiodownload_allowed===true&&!!r.audiodownload'));
ok('não mostra o rótulo repetido Jamendo · ver licença', !html.includes('Jamendo ·') && !html.includes('jamendo-credit'));
ok('mantém backlink discreto pelo nome do artista', html.includes('class="beat-artist"') && html.includes('zJmTrackUrl'));
ok('botão de salvar/apagar está restaurado', html.includes('function zDlHT(i)') && html.includes('function zDlRow(k)') && html.includes('function zDl(i)'));
ok('player reutiliza o arquivo salvo antes de buscar pela rede', html.includes('const saved=ZLOCAL.has(k)||!!ZDL[k]') && html.includes('return saved?go().catch(()=>pull()):pull()'));
ok('a migração preserva jmraw6 e combina com jmraw7', html.includes("localStorage.getItem('jmraw6')") && html.includes('...(Array.isArray(ZLEGACY[st])?ZLEGACY[st]:[])') && html.includes("zSv('jmraw7',ZRAW)"));
ok('análise assíncrona não bloqueia a interface', html.includes('function zAnalyzeAsync(') && html.includes('new Worker(url)') && !html.includes('rimaAnalyze(zMono(buf)'));
ok('stage é desenhado antes de iniciar o carregamento', html.includes('requestAnimationFrame(()=>requestAnimationFrame(()=>{if(screen.hidden)return;try{start();pk()}'));
ok('tela de treino tem fallback se áudio falhar', html.includes('Esse beat não abriu. Iniciei uma base do Rima Lab'));
ok('sem estado infinito de análise enquanto baixa', html.includes('ZS.loadingAudio?\'Carregando beat...\'') && html.includes('tempo de carregamento excedido'));

// Executa o bloco real de normalização/migração com uma cópia em memória dos dados da versão antiga.
const start = html.indexOf('let ZLEGACY={};');
const endMarker = "if(ZMIGRATED)zSv('jmraw7',ZRAW);";
const end = html.indexOf(endMarker, start);
if (start < 0 || end < 0) throw new Error('Bloco de migração não encontrado');
const migration = html.slice(start, end + endMarker.length);
const legacy = {};
for (const [style, count] of [['Boom bap', 29], ['Trap', 40], ['Drill', 40]]) {
  legacy[style] = Array.from({length: count}, (_, i) => [
    `https://prod-1.storage.jamendo.com/download/track/${style.replace(/ /g,'')}${i}/mp32/`,
    `${style} beat ${i + 1}`, 0, 0, `${style.replace(/ /g,'')}-${i + 1}`, style, `Artista ${i + 1}`
  ]);
}
const current = {'Boom bap': [['https://stream.test/track','Duplicate',0,0,'Boombap-1','Boom bap','Artist','https://www.jamendo.com/track/Boombap-1']], Trap: [], Drill: []};
const store = new Map([['jmraw6', JSON.stringify(legacy)], ['jmraw7', JSON.stringify(current)], ['dlmeta1', '{}']]);
const context = {
  ZRAW: current,
  ZMETA: {},
  ZLOCAL: new Set(),
  ZDL: {},
  ZLIB: {'Boom bap':[92,[]],Trap:[140,[]],Drill:[142,[]]},
  localStorage: {getItem: k => store.get(k) ?? null, setItem: (k,v) => store.set(k,String(v))},
  JSON, Object, Array, String, Number, Set, Math
};
vm.runInNewContext(migration + `\nglobalThis.migratedCounts=Object.fromEntries(Object.keys(ZRAW).map(k=>[k,ZRAW[k].length]));globalThis.first=ZRAW['Boom bap'][0];globalThis.downloadOK=ZRAW['Boom bap'][0][10];globalThis.saved=localStorage.getItem('jmraw7');`, context);
ok('migra e preserva as contagens antigas 29/40/40', context.migratedCounts['Boom bap'] === 29 && context.migratedCounts.Trap === 40 && context.migratedCounts.Drill === 40);
ok('deduplica a faixa já presente no catálogo novo', context.migratedCounts['Boom bap'] === 29);
ok('converte links antigos em streams e mantém permissão de offline', context.first[0].includes('storage.jamendo.com') && context.downloadOK === true);
ok('persiste o catálogo migrado em jmraw7', typeof context.saved === 'string' && context.saved.includes('Boom bap beat 1'));

let failed = 0;
for (const [name, pass] of checks) { console.log((pass ? 'OK  ' : 'FAIL ') + name); if (!pass) failed++; }
console.log(`${checks.length - failed}/${checks.length} verificações do catálogo passaram`);
process.exit(failed ? 1 : 0);
