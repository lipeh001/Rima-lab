/* Analisador de beat do Rima Lab.
   Entrada: áudio mono (Float32Array) + taxa de amostragem. Saída: BPM exato, onde cai o tempo 1 e onde está a virada.
   É o MESMO código que roda dentro do app (colado no HTML por tools/inline.py) e no script offline (tools/analisar.js). */
/*ANALYZER_START*/
function rimaAnalyze(x,sr,opt){
opt=opt||{};
const F=Math.max(1,Math.round(sr/11025)),sr2=sr/F,H=64,n2=Math.floor(x.length/F),nf=Math.floor(n2/H),hs=H/sr2;
if(nf<1200)return null;
/* 1) energia por quadro (~6 ms) em duas faixas: grave (bumbo) e resto (caixa, chimbal) */
const rl=new Float32Array(nf),rh=new Float32Array(nf),a1=1-Math.exp(-2*Math.PI*150/sr2);
let p1=0,p2=0,el=0,eh=0,c=0,fi=0;
for(let i=0;i<nf*H;i++){let s=0;const b=i*F;for(let k=0;k<F;k++)s+=x[b+k];s/=F;
p1+=a1*(s-p1);p2+=a1*(p1-p2);const h=s-p1;el+=p2*p2;eh+=h*h;
if(++c==H){rl[fi]=Math.sqrt(el/H);rh[fi]=Math.sqrt(eh/H);fi++;el=eh=c=0}}
const pc=(a,q)=>{const s=Float32Array.from(a).sort();return s[Math.min(s.length-1,Math.floor(s.length*q))]};
const rlf=pc(rl,.95)||1e-6,rhf=pc(rh,.95)||1e-6,cl=new Float32Array(nf),ch=new Float32Array(nf),Ef=new Float64Array(nf+1);
for(let i=0;i<nf;i++){cl[i]=Math.log(1+30*rl[i]/rlf);ch[i]=Math.log(1+30*rh[i]/rhf);Ef[i+1]=Ef[i]+Math.sqrt(rl[i]*rl[i]/(rlf*rlf)+rh[i]*rh[i]/(rhf*rhf))}
/* 2) início de golpes: subida da energia (comprimida) */
const ol=new Float32Array(nf),oh=new Float32Array(nf),ob=new Float32Array(nf);let ml=0,mh=0;
for(let i=2;i<nf;i++){ol[i]=Math.max(0,cl[i]-(cl[i-1]+cl[i-2])/2);oh[i]=Math.max(0,ch[i]-(ch[i-1]+ch[i-2])/2);ml+=ol[i];mh+=oh[i]}
ml=ml/nf||1e-6;mh=mh/nf||1e-6;
for(let i=0;i<nf;i++){ol[i]/=ml;oh[i]/=mh;ob[i]=ol[i]+.7*oh[i]}
/* 3) andamento: dobra o sinal no tamanho de um compasso. No BPM certo os golpes de todos os compassos caem nos mesmos lugares (pico fino) */
const fold=(bp,NB,arr,n,i0)=>{const B=240/bp,h=new Float64Array(NB),inc=hs*NB/B;n=n||nf;for(let i=i0||0;i<n;i++){let p=(i+.5)*inc;p-=Math.floor(p/NB)*NB;const b=Math.floor(p),f=p-b;h[b]+=arr[i]*(1-f);h[b+1>=NB?0:b+1]+=arr[i]*f}return h};
const conc=h=>{let s=0,t=0;for(let i=0;i<h.length;i++){s+=h[i]*h[i];t+=h[i]}return s/(t*t||1)*h.length};
const prior=opt.hint||100,sg=opt.hint?.35:.7,pw=bp=>Math.exp(-.5*Math.pow(Math.log2(bp/prior)/sg,2));
const nfa=Math.min(nf,Math.floor(130/hs)),co=[];
for(let bp=60;bp<=150.001;bp+=.1)co.push([bp,conc(fold(bp,96,ob,nfa))*pw(bp)]);
const pk=[];for(let i=0;i<co.length;i++){let ok=1;for(let d=-12;d<=12;d++){const j=i+d;if(j>=0&&j<co.length&&co[j][1]>co[i][1])ok=0}if(ok)pk.push(co[i])}
pk.sort((a,b)=>b[1]-a[1]);
let bpm=pk[0][0],bs=-1;
for(const [b0] of pk.slice(0,3)){let lb=b0,ls=-1;for(let bp=b0-.15;bp<=b0+.15;bp+=.01){const s=conc(fold(bp,256,ob))*pw(bp);if(s>ls){ls=s;lb=bp}}if(ls>bs){bs=ls;bpm=lb}}
{let lb=bpm,ls=-1;for(let bp=bpm-.012;bp<=bpm+.012;bp+=.001){const s=conc(fold(bp,256,ob));if(s>ls){ls=s;lb=bp}}bpm=lb}
const P=60/bpm,B=4*P,NB=256,sb=NB/4;
/* 4) virada: primeiro ponto onde a música "enche" (energia dos próximos 2 compassos bem maior que a dos 2 anteriores) */
const Es=Float32Array.from({length:Math.floor(nf/16)},(_,i)=>(Ef[Math.min(nf,i*16+16)]-Ef[i*16])/16).sort(),G=Es[Math.floor(Es.length*.8)]||1;
const mean=(t0,t1)=>{const a=Math.max(0,Math.round(t0/hs)),b=Math.min(nf,Math.round(t1/hs));return b>a?(Ef[b]-Ef[a])/(b-a):0};
const W=8*P,st=P/4,tmax=Math.min(nf*hs-W,90),dn=[];let dM=0;
for(let t=W/2;t<=tmax;t+=st){const a=mean(t,t+W),b=mean(t-W,t),d=a<G*.4?0:(a-b)/G;dn.push(d);if(d>dM)dM=d}
let D=-1,dStr=0;
if(dM>=.12){const th=Math.max(.12,dM*.55);for(let i=0;i<dn.length;i++){if(dn[i]<th)continue;let j=i;while(j+1<dn.length&&dn[j+1]>=dn[j])j++;
const tj=W/2+j*st;let bt=tj,bv=-1e9;for(let t=tj-W/2;t<=tj+W/4;t+=P/8){if(t<P)continue;const v=mean(t,t+4*P)-mean(t-4*P,t);if(v>bv){bv=v;bt=t}}
let bo=bt,bm=-1;for(let k=Math.max(0,Math.round((bt-P/2)/hs));k<=Math.round((bt+P/2)/hs)&&k<nf-3;k++){const v=ob[k]+ob[k+1]+ob[k+2];if(v>bm){bm=v;bo=k*hs}}
D=bo;dStr=dn[j];break}}
/* 5) onde cai o tempo 1: bumbo forte nele, caixa nas batidas 2 e 4. i0 = quadro onde começa o trecho medido; uD = usa a virada como dica */
const w=Math.max(1,Math.round(.02/B*NB)),bias=opt.onsetBias==null?.0055:opt.onsetBias;
const fase=(i0,uD)=>{const hl=fold(bpm,NB,ol,nf,i0),hh=fold(bpm,NB,oh,nf,i0);let sl=0,sh=0;for(let i=0;i<NB;i++){sl+=hl[i];sh+=hh[i]}sl/=NB;sh/=NB;
for(let i=0;i<NB;i++){hl[i]/=sl||1;hh[i]/=sh||1}
const at=(h,b)=>{let s=0;b=Math.round(b);for(let d=-w;d<=w;d++)s+=h[(((b+d)%NB)+NB)%NB];return s/(2*w+1)};
const sc=new Float64Array(NB);let sM=0;
for(let b=0;b<NB;b++){sc[b]=at(hl,b)+.5*at(hl,b+2*sb)+.6*(at(hh,b+sb)+at(hh,b+3*sb))-.3*(at(hh,b)+at(hh,b+2*sb));if(sc[b]>sM)sM=sc[b]}
if(uD&&D>=0&&dStr>=.18){const bd=((D%B)/B)*NB;for(let b=0;b<NB;b++){let d=Math.abs(b+.5-bd);d=Math.min(d,NB-d);sc[b]+=.7*sM*Math.exp(-Math.pow(d/(.03/B*NB),2))}}
let b0=0;for(let b=1;b<NB;b++)if(sc[b]>sc[b0])b0=b;
let cw=0,cs=0;for(let d=-w;d<=w;d++){const j=(((b0+d)%NB)+NB)%NB,v=hl[j]+.5*hh[j];cw+=v;cs+=v*(b0+d+.5)}
const ctr=cw>0?cs/cw:b0+.5;return(((ctr/NB)*B-bias)%B+B)%B};
/* 6) tempo 1 = primeiro bumbo do beat completo. A virada (energia) só diz "por volta daqui": risers, caixa rolando e pausa antes do bumbo
   fazem ela cair 1 a 3 compassos ANTES do primeiro bumbo. Então, em cima da grade g0, olha compasso a compasso se o bumbo no tempo 1 e a
   densidade de bumbos do compasso já estão no nível do resto do beat, e crava o tempo 1 no primeiro compasso assim (sustentado nos seguintes). */
const primeiro=g0=>{const nbr=Math.min(Math.floor((nf*hs-g0)/B),Math.floor(120/B));
if(nbr>=6){const Kd=new Float64Array(nbr),Ld=new Float64Array(nbr),fk=Math.max(1,Math.round(.04/hs));
for(let k=0;k<nbr;k++){const c=Math.round((g0+k*B)/hs),a=Math.max(0,c-fk),z=Math.min(nf-1,c+fk+Math.round(.03/hs));let m=0;for(let i=a;i<=z;i++)if(ol[i]>m)m=ol[i];Kd[k]=m;
const b0=Math.max(0,c),b1=Math.min(nf,Math.round((g0+(k+1)*B)/hs));let t=0;for(let i=b0;i<b1;i++)t+=ol[i];Ld[k]=t}
const q=(A,p)=>{const s=Float64Array.from(A).sort();return s[Math.min(s.length-1,Math.floor(s.length*p))]},Kr=q(Kd,.7),Lr=q(Ld,.7);
const full=k=>k<nbr&&Kd[k]>=.5*Kr&&Ld[k]>=.55*Lr,sus=k=>full(k)&&full(k+1)&&(full(k+2)||full(k+3));
const k0=D>=0?Math.max(0,Math.round((D-g0)/B)):0,lo=D>=0?Math.max(0,k0-1):0,hi=D>=0?Math.min(nbr-4,k0+6):Math.min(nbr-4,40);let kk=-1;
for(let k=lo;k<=hi;k++)if(sus(k)){kk=k;break}
let d=-1;if(kk>=0){if(D>=0||kk>=2)d=g0+kk*B}else if(D>=0)d=g0+k0*B;return d>0?d:-1}
if(D>=0){const kk=Math.round((D-g0)/B),d=g0+kk*B;return d>0?d:-1}return -1};
/* duas leituras da fase (com e sem a dica da virada): fica com a que tem o bumbo mais firme no tempo 1 ao longo do trecho completo */
const qual=(g,d)=>{if(!(d>0))return 0;const fk=Math.max(1,Math.round(.04/hs)),n0=Math.floor((nf*hs-d)/B),n=Math.min(n0,12);if(n<3)return 0;let t=0;
for(let k=0;k<n;k++){const c=Math.round((d+k*B)/hs);let m=0;for(let i=Math.max(0,c-fk);i<=Math.min(nf-1,c+fk);i++)if(ob[i]>m)m=ob[i];t+=m}return t/n};
let g0=fase(0,true),drop=primeiro(g0);
{const gB=fase(0,false),dd=Math.abs(((gB-g0)%B+B*1.5)%B-B/2);
if(dd>.02){const dB=primeiro(gB);if(qual(gB,dB>0?dB:gB+B)>1.15*qual(g0,drop>0?drop:g0+B)){g0=gB;drop=dB}}}
return{bpm:Math.round(bpm*1000)/1000,g0:Math.round(g0*1000)/1000,drop:drop>0?Math.round(drop*1000)/1000:-1,conf:Math.round(bs*10)/10}}
/* Beats do SoundCloud: não temos o áudio, só a forma de onda (~1800 valores, um a cada ~0,1 s). Mesmo assim, ao longo de uns 200 batidas dá para achar o BPM exato e a fase.
   sm = amostras da forma de onda, dur = duração em s, opt.hint = BPM aproximado, opt.drop = virada achada (s) ou -1 */
function rimaWave(sm,dur,opt){
opt=opt||{};const n=sm&&sm.length;if(!(n>300)||!(dur>20))return null;
const sps=n/dur,r=new Float64Array(n);let m=0;
r[0]=sm[0]>0?sm[0]:0;m=r[0];for(let i=1;i<n;i++){const d=sm[i]-sm[i-1];if(d>0){r[i]=d;m+=d}}
m=m/n||1e-9;for(let i=0;i<n;i++)r[i]/=m;
const prior=opt.hint||100,sg=opt.hint?.35:.7,pw=bp=>Math.exp(-.5*Math.pow(Math.log2(bp/prior)/sg,2));
const sc=(bp,ph)=>{const P=60/bp;let s=0,c=0;for(let t=ph;t<dur-.3;t+=P){s+=r[Math.min(n-1,Math.floor(t*sps+1e-9))];c++}return s/(c||1)};
const best=(bp,ps)=>{const P=60/bp;let b=-1,bph=0;for(let ph=0;ph<P;ph+=ps){const v=sc(bp,ph);if(v>b){b=v;bph=ph}}return[b,bph]};
const co=[];for(let bp=60;bp<=150.001;bp+=.1){const[v,ph]=best(bp,.012);co.push([bp,v*pw(bp),ph])}
const pk=[];for(let i=0;i<co.length;i++){let ok=1;for(let d=-10;d<=10;d++){const j=i+d;if(j>=0&&j<co.length&&co[j][1]>co[i][1])ok=0}if(ok)pk.push(co[i])}
pk.sort((a,b)=>b[1]-a[1]);
let bpm=pk[0][0],ph=pk[0][2],bs=-1;
for(const[b0]of pk.slice(0,3)){let lb=b0,lp=0,ls=-1;for(let bp=b0-.1;bp<=b0+.1;bp+=.004){const[v,p]=best(bp,.004);const w=v*pw(bp);if(w>ls){ls=w;lb=bp;lp=p}}if(ls>bs){bs=ls;bpm=lb;ph=lp}}
{/* ajuste final: média da região de maior pontuação (evita escolher um degrau qualquer do platô) */
const P0=60/bpm,cand=[];let vm=-1;for(let bp=bpm-.08;bp<=bpm+.08;bp+=.002){const P=60/bp;for(let d=-.03;d<=.03;d+=.002){let p=ph+d;p=((p%P)+P)%P;const v=sc(bp,p);cand.push([bp,d,v]);if(v>vm)vm=v}}
let sw=0,sb=0,sd=0;for(const[bp,d,v]of cand){const w=Math.max(0,v-.93*vm);sw+=w;sb+=w*bp;sd+=w*d}
if(sw>0){bpm=sb/sw;const P=60/bpm;ph=(((ph+sd/sw)%P)+P)%P}}
const conf=sc(bpm,ph);if(conf<1.4)return null;
const P=60/bpm,B=4*P;
/* virada: primeiro ponto onde a música "enche" (energia das próximas 2 compassos bem maior que a das 2 anteriores), medida batida a batida */
const nb=Math.max(0,Math.floor((dur-ph)/P)-1),E=new Float64Array(nb);
for(let k=0;k<nb;k++){const a=Math.floor((ph+k*P)*sps),b=Math.min(n,Math.max(a+1,Math.floor((ph+(k+1)*P)*sps)));let t=0;for(let i=a;i<b;i++)t+=sm[i];E[k]=t/(b-a)}
const Es=Float64Array.from(E).sort(),G=Es[Math.floor(Es.length*.8)]||1,me=(a,b)=>{a=Math.max(0,a);b=Math.min(nb,b);if(b<=a)return 0;let t=0;for(let i=a;i<b;i++)t+=E[i];return t/(b-a)};
const kmax=Math.min(nb-8,Math.floor(90/P)),dn=new Float64Array(Math.max(0,kmax+1));let dM=0;
for(let k=4;k<=kmax;k++){const a=me(k,k+8),b=me(k-8,k);dn[k]=a<G*.4?0:(a-b)/G;if(dn[k]>dM)dM=dn[k]}
let dk=-1;
if(dM>=.12){const th=Math.max(.12,dM*.55);for(let k=4;k<=kmax;k++){if(dn[k]<th)continue;let j=k;while(j+1<=kmax&&dn[j+1]>=dn[j])j++;let bk=j,bv=-1e9;for(let q=Math.max(4,j-8);q<=Math.min(nb-4,j+4);q++){const v=me(q,q+4)-me(q-4,q);if(v>bv){bv=v;bk=q}}dk=bk;break}}
let D=-1;
if(dk>=0){/* o golpe mais forte na virada diz se a grade está na batida ou no contratempo */
let bi=Math.floor((ph+dk*P)*sps),bm=-1,bt=0;for(let i=Math.max(1,bi-Math.ceil(P*sps)-1);i<=Math.min(n-1,bi+Math.ceil(P*sps)+1);i++)if(r[i]>bm){bm=r[i];bt=(i+.5)/sps}D=bt}
else if(opt.drop>0)D=opt.drop;
if(D>0){const dist=p=>{const k=Math.round((D-p)/P);return Math.abs(D-(p+k*P))};const alt=(ph+P/2)%P;if(dist(alt)<dist(ph))ph=alt}
let g0,drop=-1;
if(D>0){const k=Math.round((D-ph)/P),db=ph+k*P;g0=((db%B)+B)%B;drop=db}
else{let f=0;for(let i=0;i<n;i++)if(r[i]>3&&sm[i]>0){f=i/sps;break}const k=Math.round((f-ph)/P);g0=(((ph+k*P)%B)+B)%B}
return{bpm:Math.round(bpm*1000)/1000,g0:Math.round(g0*1000)/1000,drop:drop>0?Math.round(drop*1000)/1000:-1,conf:Math.round(conf*10)/10}}
/*ANALYZER_END*/
if(typeof module!=='undefined')module.exports={rimaAnalyze,rimaWave};
