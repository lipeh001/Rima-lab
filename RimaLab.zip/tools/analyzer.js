/* Analisador de beat do Rima Lab.
   Entrada: áudio mono (Float32Array) + taxa de amostragem. Saída: BPM exato, onde cai o tempo 1 e onde está a virada.
   É o MESMO código que roda dentro do app (colado no HTML por tools/inline.py) e no script offline (tools/analisar.js). */
/*ANALYZER_START*/
function rimaAnalyze0(x,sr,opt){
opt=opt||{};
const F=Math.max(1,Math.round(sr/11025)),sr2=sr/F,H=64,n2=Math.floor(x.length/F),nf=Math.floor(n2/H),hs=H/sr2;
if(nf<1200)return null;
/* 1) energia por quadro (~6 ms) em duas faixas: grave (bumbo) e resto (caixa, chimbal) */
const rl=new Float32Array(nf),rh=new Float32Array(nf),a1=1-Math.exp(-2*Math.PI*150/sr2);
let p1=0,p2=0,el=0,eh=0,c=0,fi=0;
for(let i=0;i<nf*H;i++){let s=0;const b=i*F;for(let k=0;k<F;k++)s+=x[b+k];s/=F;
p1+=a1*(s-p1);p2+=a1*(p1-p2);const h=s-p1;el+=p2*p2;eh+=h*h;
if(++c==H){rl[fi]=Math.sqrt(el/H);rh[fi]=Math.sqrt(eh/H);fi++;el=eh=c=0}}
const pc=(a,q)=>{const s=Float32Array.from(a).sort();return s[Math.min(s.length-1,Math.floor(s.length*q))]};
const rlf=pc(rl,.95)||1e-6,rhf=pc(rh,.95)||1e-6,cl=new Float32Array(nf),ch=new Float32Array(nf),Ef=new Float64Array(nf+1);
for(let i=0;i<nf;i++){cl[i]=Math.log(1+30*rl[i]/rlf);ch[i]=Math.log(1+30*rh[i]/rhf);Ef[i+1]=Ef[i]+Math.sqrt(rl[i]*rl[i]/(rlf*rlf)+rh[i]*rh[i]/(rhf*rhf))}
/* 2) início de golpes: subida da energia (comprimida) */
const ol=new Float32Array(nf),oh=new Float32Array(nf),ob=new Float32Array(nf);let ml=0,mh=0;
for(let i=2;i<nf;i++){ol[i]=Math.max(0,cl[i]-(cl[i-1]+cl[i-2])/2);oh[i]=Math.max(0,ch[i]-(ch[i-1]+ch[i-2])/2);ml+=ol[i];mh+=oh[i]}
ml=ml/nf||1e-6;mh=mh/nf||1e-6;
for(let i=0;i<nf;i++){ol[i]/=ml;oh[i]/=mh;ob[i]=ol[i]+.7*oh[i]}
const ol2=new Float32Array(nf);{let m2=0;for(let i=2;i<nf;i++){ol2[i]=Math.max(0,rl[i]-(rl[i-1]+rl[i-2])/2);m2+=ol2[i]}m2=m2/nf||1e-9;for(let i=0;i<nf;i++)ol2[i]/=m2}
/* 3) andamento: dobra o sinal no tamanho de um compasso. No BPM certo os golpes de todos os compassos caem nos mesmos lugares (pico fino) */
const fold=(bp,NB,arr,n,i0)=>{const B=240/bp,h=new Float64Array(NB),inc=hs*NB/B;n=n||nf;for(let i=i0||0;i<n;i++){let p=(i+.5)*inc;p-=Math.floor(p/NB)*NB;const b=Math.floor(p),f=p-b;h[b]+=arr[i]*(1-f);h[b+1>=NB?0:b+1]+=arr[i]*f}return h};
const conc=h=>{let s=0,t=0;for(let i=0;i<h.length;i++){s+=h[i]*h[i];t+=h[i]}return s/(t*t||1)*h.length};
const prior=opt.hint||100,sg=opt.hint?.35:.7,pw=bp=>Math.exp(-.5*Math.pow(Math.log2(bp/prior)/sg,2));
const nfa=Math.min(nf,Math.floor(130/hs)),co=[];
for(let bp=60;bp<=150.001;bp+=.1)co.push([bp,conc(fold(bp,96,ob,nfa))*pw(bp)]);
const pk=[];for(let i=0;i<co.length;i++){let ok=1;for(let d=-12;d<=12;d++){const j=i+d;if(j>=0&&j<co.length&&co[j][1]>co[i][1])ok=0}if(ok)pk.push(co[i])}
pk.sort((a,b)=>b[1]-a[1]);
let bpm=pk[0][0],bs=-1;
for(const [b0] of pk.slice(0,3)){let lb=b0,ls=-1;for(let bp=b0-.15;bp<=b0+.15;bp+=.01){const s=conc(fold(bp,256,ob))*pw(bp);if(s>ls){ls=s;lb=bp}}if(ls>bs){bs=ls;bpm=lb}}
{let lb=bpm,ls=-1;for(let bp=bpm-.012;bp<=bpm+.012;bp+=.001){const s=conc(fold(bp,256,ob));if(s>ls){ls=s;lb=bp}}bpm=lb}
if(Math.abs(bpm-Math.round(bpm))<.06)bpm=Math.round(bpm);
const P=60/bpm,B=4*P,NB=256,sb=NB/4;
/* 4) virada: primeiro ponto onde a música "enche" (energia dos próximos 2 compassos bem maior que a dos 2 anteriores) */
const Es=Float32Array.from({length:Math.floor(nf/16)},(_,i)=>(Ef[Math.min(nf,i*16+16)]-Ef[i*16])/16).sort(),G=Es[Math.floor(Es.length*.8)]||1;
const mean=(t0,t1)=>{const a=Math.max(0,Math.round(t0/hs)),b=Math.min(nf,Math.round(t1/hs));return b>a?(Ef[b]-Ef[a])/(b-a):0};
const W=8*P,st=P/4,tmax=Math.min(nf*hs-W,90),dn=[];let dM=0;
for(let t=W;t<=tmax;t+=st){const a=mean(t,t+W),b=mean(t-W,t),d=a<G*.4?0:(a-b)/G;dn.push(d);if(d>dM)dM=d}
let D=-1,dStr=0;
if(dM>=.12){const th=Math.max(.12,dM*.55);for(let i=0;i<dn.length;i++){if(dn[i]<th)continue;let j=i;while(j+1<dn.length&&dn[j+1]>=dn[j])j++;
const tj=W+j*st;let bt=tj,bv=-1e9;for(let t=tj-W/2;t<=tj+W/4;t+=P/8){if(t<P)continue;const v=mean(t,t+4*P)-mean(t-4*P,t);if(v>bv){bv=v;bt=t}}
let bo=bt,bm=-1;for(let k=Math.max(0,Math.round((bt-P/2)/hs));k<=Math.round((bt+P/2)/hs)&&k<nf-3;k++){const v=ob[k]+ob[k+1]+ob[k+2];if(v>bm){bm=v;bo=k*hs}}
D=bo;dStr=dn[j];break}}
/* 4b) primeiro bumbo do ritmo sustentado: 1º golpe grave forte que tem pelo menos 3 irmãos nos 2 compassos seguintes. Beats sem introdução começam no tempo 1, então esse golpe cai nele */
let T1=-1;{const th=1.8,L2=Math.round(2*B/hs),lim=Math.min(nf-L2-1,Math.round(100/hs));for(let i=3;i<lim;i++){if(ol[i]<th||ol[i]<ol[i-1]||ol[i]<ol[i+1])continue;let c=0,last=i;for(let j=i+Math.round(.09/hs);j<i+L2;j++)if(ol[j]>=th&&ol[j]>=ol[j-1]&&ol[j]>=ol[j+1]&&j-last>.07/hs){c++;last=j}if(c>=3){let bi=i,bv=0;for(let k=Math.max(0,i-2);k<=i+3;k++)if(ol[k]>bv){bv=ol[k];bi=k}T1=bi*hs;break}}}
/* 5) onde cai o tempo 1: bumbo forte nele, caixa nas batidas 2 e 4. i0 = quadro onde começa o trecho medido; uD = usa a virada como dica */
/* mudança de nota grave / acorde (sem transiente): cai no começo do compasso e ajuda a separar o tempo 1 do tempo 3 */
const hb=Math.max(2,Math.round(P/2/hs)),Cc=new Float64Array(nf+1);for(let i=0;i<nf;i++)Cc[i+1]=Cc[i]+cl[i];
const nl=new Float32Array(nf);let mn_=0;for(let i=hb;i<nf-hb;i++){nl[i]=Math.abs((Cc[i+hb]-Cc[i])-(Cc[i]-Cc[i-hb]))/hb;mn_+=nl[i]}mn_=mn_/nf||1e-6;for(let i=0;i<nf;i++)nl[i]/=mn_;
const NW=opt.nw==null?.5:opt.nw,w=Math.max(1,Math.round(.02/B*NB)),bias=opt.onsetBias==null?.0055:opt.onsetBias;
const fase=(i0,uD)=>{const hl=fold(bpm,NB,ol,nf,i0),hh=fold(bpm,NB,oh,nf,i0),hn=fold(bpm,NB,nl,nf,i0);let sl=0,sh=0,sn=0;for(let i=0;i<NB;i++){sl+=hl[i];sh+=hh[i];sn+=hn[i]}sl/=NB;sh/=NB;sn/=NB;
for(let i=0;i<NB;i++){hl[i]/=sl||1;hh[i]/=sh||1;hn[i]/=sn||1}
const at=(h,b)=>{let s=0;b=Math.round(b);for(let d=-w;d<=w;d++)s+=h[(((b+d)%NB)+NB)%NB];return s/(2*w+1)};
const sc=new Float64Array(NB);let sM=0;
for(let b=0;b<NB;b++){sc[b]=at(hl,b)+.5*at(hl,b+2*sb)+.6*(at(hh,b+sb)+at(hh,b+3*sb))-.3*(at(hh,b)+at(hh,b+2*sb))+NW*at(hn,b);if(sc[b]>sM)sM=sc[b]}
if(uD&&D>=0&&dStr>=.18){const bd=((D%B)/B)*NB;for(let b=0;b<NB;b++){let d=Math.abs(b+.5-bd);d=Math.min(d,NB-d);sc[b]+=.55*sM*Math.exp(-Math.pow(d/(.03/B*NB),2))}}
if(T1>=0){const bd=((T1%B)/B)*NB;for(let b=0;b<NB;b++){let d=Math.abs(b+.5-bd);d=Math.min(d,NB-d);sc[b]+=.8*sM*Math.exp(-Math.pow(d/(.04/B*NB),2))}}
let b0=0;for(let b=1;b<NB;b++)if(sc[b]>sc[b0])b0=b;
let cw=0,cs=0;for(let d=-w;d<=w;d++){const j=(((b0+d)%NB)+NB)%NB,v=hl[j]+.5*hh[j];cw+=v;cs+=v*(b0+d+.5)}
const ctr=cw>0?cs/cw:b0+.5;return(((ctr/NB)*B-bias)%B+B)%B};
/* 6) tempo 1 = primeiro bumbo do beat completo. A virada (energia) só diz "por volta daqui": risers, caixa rolando e pausa antes do bumbo
   fazem ela cair 1 a 3 compassos ANTES do primeiro bumbo. Então, em cima da grade g0, olha compasso a compasso se o bumbo no tempo 1 e a
   densidade de bumbos do compasso já estão no nível do resto do beat, e crava o tempo 1 no primeiro compasso assim (sustentado nos seguintes). */
const primeiro=g0=>{const nbr=Math.min(Math.floor((nf*hs-g0)/B),Math.floor(120/B));
if(nbr>=6){const Kd=new Float64Array(nbr),Km=new Float64Array(nbr),Ld=new Float64Array(nbr),fk=Math.max(1,Math.round(.04/hs));
for(let k=0;k<nbr;k++){const c=Math.round((g0+k*B)/hs),a=Math.max(0,c-fk),z=Math.min(nf-1,c+fk+Math.round(.03/hs));let m=0;for(let i=a;i<=z;i++)if(ol2[i]>m)m=ol2[i];Kd[k]=m;
const b0=Math.max(0,c),b1=Math.min(nf,Math.round((g0+(k+1)*B)/hs));let t=0,mk=0;for(let i=b0;i<b1;i++){t+=ol2[i];if(ol2[i]>mk)mk=ol2[i]}Ld[k]=t;Km[k]=mk}
const q=(A,p)=>{const s=Float64Array.from(A).sort();return s[Math.min(s.length-1,Math.floor(s.length*p))]},Kr=q(Kd,.7),Lr=q(Ld,.7),Mr=q(Km,.7);
/* compasso cheio = densidade de bumbos do nível do resto do beat E um bumbo forte em qualquer lugar do compasso (boom bap real nem sempre tem bumbo no tempo 1 de todo compasso) */
const full=k=>k<nbr&&(Kd[k]>=.5*Kr||Km[k]>=.7*Mr)&&Ld[k]>=.55*Lr,sus=k=>full(k)&&full(k+1)&&(full(k+2)||full(k+3));
const k0=D>=0?Math.max(0,Math.round((D-g0)/B)):0,lo=D>=0?Math.max(0,k0-1):0,hi=D>=0?Math.min(nbr-4,k0+6):Math.min(nbr-4,40);let kk=-1;
for(let k=lo;k<=hi;k++)if(sus(k)){kk=k;break}
let d=-1;if(kk>=0){if(D>=0||kk>=2)d=g0+kk*B}else if(D>=0)d=g0+k0*B;return d>0?d:-1}
if(D>=0){const kk=Math.round((D-g0)/B),d=g0+kk*B;return d>0?d:-1}return -1};
/* duas leituras da fase (com e sem a dica da virada): fica com a que tem o bumbo mais firme no tempo 1 ao longo do trecho completo */
const qual=(g,d)=>{if(!(d>0))return 0;const fk=Math.max(1,Math.round(.04/hs)),n0=Math.floor((nf*hs-d)/B),n=Math.min(n0,12);if(n<3)return 0;let t=0;
for(let k=0;k<n;k++){const c=Math.round((d+k*B)/hs);let m=0;for(let i=Math.max(0,c-fk);i<=Math.min(nf-1,c+fk);i++)if(ob[i]>m)m=ob[i];t+=m}return t/n};
let g0=fase(0,true),drop=primeiro(g0);
{const gB=fase(0,false),dd=Math.abs(((gB-g0)%B+B*1.5)%B-B/2);
if(dd>.02){const dB=primeiro(gB);if(qual(gB,dB>0?dB:gB+B)>1.15*qual(g0,drop>0?drop:g0+B)){g0=gB;drop=dB}}}
/* Segunda opinião: outro método (batida a batida, sem bônus de virada), em função própria */
const novo=()=>{/* grade de batidas e características de cada batida (rápido: tudo O(n)). phi = onde cai a batida dentro do período P */
const hb=Math.max(2,Math.round(P/2/hs)),Cc=new Float64Array(nf+1);for(let i=0;i<nf;i++)Cc[i+1]=Cc[i]+cl[i];
const nl=new Float32Array(nf);let mn_=0;for(let i=hb;i<nf-hb;i++){nl[i]=Math.abs((Cc[i+hb]-Cc[i])-(Cc[i]-Cc[i-hb]))/hb;mn_+=nl[i]}mn_=mn_/nf||1e-6;for(let i=0;i<nf;i++)nl[i]/=mn_;
const w=Math.max(1,Math.round(.02/B*NB)),bias=opt.onsetBias==null?.0055:opt.onsetBias,oc=new Float32Array(nf);for(let i=0;i<nf;i++)oc[i]=ol[i]+.5*oh[i];
const hq=new Float64Array(64);{const hbar=fold(bpm,NB,oc,nf,0);for(let i=0;i<NB;i++)hq[i&63]+=hbar[i]}
let q0=0;for(let i=1;i<64;i++)if(hq[i]>hq[q0])q0=i;
let cw=0,cs0=0;for(let d=-w;d<=w;d++){const j=(((q0+d)%64)+64)%64;cw+=hq[j];cs0+=hq[j]*(q0+d+.5)}
let phi=((((cw>0?cs0/cw:q0+.5)/64)*P-bias)%P+P)%P;
/* a dobra pode travar no contratempo (bumbo sincopado); a virada ou o 1º bumbo sustentado dizem se a batida é essa ou meia batida depois */
{const h=D>=0&&dStr>=.12?D:T1,cd=(a,b)=>{let d=Math.abs(a-b)%P;return Math.min(d,P-d)};if(h>=0){const c2=(phi+P/2)%P;if(cd(c2,h)<cd(phi,h))phi=c2}}
const M=Math.max(0,Math.min(Math.floor((nf*hs-phi)/P)-1,Math.floor(120/P))),Kb=new Float64Array(M),Sb=new Float64Array(M),Nb=new Float64Array(M),Eb=new Float64Array(M),f1=Math.round(.04/hs),f2=Math.round(.05/hs);
for(let m=0;m<M;m++){const c=Math.round((phi+m*P)/hs);let k=0,sn=0;for(let i=Math.max(0,c-f1);i<=Math.min(nf-1,c+f2);i++){if(ol2[i]>k)k=ol2[i];if(oh[i]>sn)sn=oh[i]}Kb[m]=k;Sb[m]=sn;
const a=Math.min(nf-1,Math.max(1,c));Nb[m]=(nl[a-1]+nl[a]+nl[Math.min(nf-1,a+1)])/3;const e0=Math.max(0,c),e1=Math.min(nf,Math.round((phi+(m+1)*P)/hs));Eb[m]=e1>e0?(Ef[e1]-Ef[e0])/(e1-e0):0}
/* 6) início do beat completo (m0): 1º bumbo forte, no nível do resto da música, que é seguido de ritmo de bumbos sustentado e energia cheia.
   Pega só bumbo de verdade: intro com baixo, acorde, chimbal ou caixa rolando não conta (não tem bumbo forte + ritmo sustentado + energia cheia). */
let m0=-1;
if(M>=24){const Kr=pc(Kb,.9),Er=pc(Eb,.7),dens=new Float64Array(M);for(let m=0;m+8<=M;m++){let c=0;for(let q=0;q<8;q++)if(Kb[m+q]>=.5*Kr)c++;dens[m]=c}
const Dr=pc(dens.subarray(0,M-7),.7),em=m=>{let t=0;for(let q=0;q<8;q++)t+=Eb[Math.min(M-1,m+q)];return t/8};
const Lw=new Float64Array(M);{const Po=new Float64Array(nf+1);for(let i=0;i<nf;i++)Po[i+1]=Po[i]+ol2[i];for(let m=0;m+4<=M;m++){const a=Math.max(0,Math.round((phi+m*P)/hs)),b=Math.min(nf,Math.round((phi+(m+4)*P)/hs));Lw[m]=Po[b]-Po[a]}}
const Lr=pc(Lw.subarray(0,M-3),.7);
for(let m=0;m+12<=M&&m<Math.floor(100/P);m++){if(Kb[m]<.6*Kr||dens[m]<.6*Dr||dens[m+4]<.6*Dr||Lw[m]<.55*Lr||Lw[m+4]<.55*Lr||em(m)<.6*Er)continue;m0=m;break}}
/* 7) qual das 4 batidas é o tempo 1: junta pistas independentes, cada uma normalizada de 0 a 1 entre as 4 opções.
   bumbo na batida, caixa nas batidas 2 e 4 (ou só na 3, trap/drill), troca de nota grave, e o começo do beat completo (que cai no tempo 1) */
const mb=m0>=0?m0:0,cue=arr=>{const v=[0,0,0,0],c=[0,0,0,0];for(let m=mb;m<M;m++){v[m&3]+=arr[m];c[m&3]++}return v.map((x,i)=>c[i]?x/c[i]:0)};
const nz=v=>{const lo=Math.min(...v),hi=Math.max(...v);return hi-lo>1e-9?v.map(x=>(x-lo)/(hi-lo)):[0,0,0,0]};
const ck=cue(Kb),cs=cue(Sb),cn=cue(Nb),sn=[0,1,2,3].map(j=>Math.max((cs[(j+1)&3]+cs[(j+3)&3])/2-(cs[j]+cs[(j+2)&3])/2,cs[(j+2)&3]-(cs[j]+cs[(j+1)&3]+cs[(j+3)&3])/3));
const nK=nz(ck),nS=nz(sn),nN=nz(cn),oneHot=m=>[0,1,2,3].map(j=>j==(((m%4)+4)%4)?1:0),wP=m0>=8?1.7:m0>=0?1:0,pP=m0>=0?oneHot(m0):[0,0,0,0],
pD=D>=0&&dStr>=.12?oneHot(Math.round((D-phi)/P)):[0,0,0,0];
let jb=0,sbst=-1;for(let j=0;j<4;j++){const v=1*nK[j]+.8*nS[j]+.5*nN[j]+wP*pP[j]+.5*pD[j];if(v>sbst+1e-9){sbst=v;jb=j}}
const g0n=(((phi+jb*P)%B)+B)%B;let dropn=-1;
if(m0>=8){const kb=Math.round((m0-jb)/4),t=phi+(jb+4*kb)*P;if(t>B*.9)dropn=t}
return{g0:g0n,drop:dropn}};
/* Verificação independente de uma resposta (g0, drop): olha o trecho completo do beat e pontua bumbo no tempo 1, caixa nos tempos 2 e 4 (ou só no 3),
   troca de nota grave no tempo 1 e o salto de densidade de golpes graves na virada. As duas respostas são medidas com a mesma régua. */
const verif=(g,d)=>{const k0=d>0?Math.max(0,Math.round((d-g)/B)):1,K=[0,0,0,0],S=[0,0,0,0],Nn=[0,0,0,0];let cnt=0;const f1=Math.round(.04/hs),f2=Math.round(.05/hs);
for(let k=k0;k<k0+16;k++){const t0=g+k*B;if(t0+B>nf*hs)break;cnt++;for(let q=0;q<4;q++){const c=Math.round((t0+q*P)/hs);let kk=0,ss=0;for(let i=Math.max(0,c-f1);i<=Math.min(nf-1,c+f2);i++){if(ol2[i]>kk)kk=ol2[i];if(oh[i]>ss)ss=oh[i]}K[q]+=kk;S[q]+=ss;Nn[q]+=nl[Math.min(nf-1,Math.max(0,c))]}}
if(cnt<3)return -9;const tk=(K[0]+K[1]+K[2]+K[3])/4+1e-6,ts=(S[0]+S[1]+S[2]+S[3])/4+1e-6,tn=(Nn[0]+Nn[1]+Nn[2]+Nn[3])/4+1e-6;
const kc=(K[0]-(K[1]+K[2]+K[3])/3)/tk,sc=Math.max((S[1]+S[3])/2-(S[0]+S[2])/2,S[2]-(S[0]+S[1]+S[3])/3)/ts,nc=(Nn[0]-(Nn[1]+Nn[2]+Nn[3])/3)/tn;
let st=0;if(d>0){const dens=(t0,t1)=>{let s=0;for(let i=Math.max(0,Math.round(t0/hs));i<Math.min(nf,Math.round(t1/hs));i++)s+=ol2[i];return s},af=dens(d,d+3*B),bf=dens(Math.max(0,d-2*B),d);st=(af/3-bf/Math.max(1,Math.min(2,d/B)))/((af/3+bf/Math.max(1,Math.min(2,d/B)))||1)}
return Math.max(-1,Math.min(2,kc))+.8*Math.max(-1,Math.min(2,sc))+.5*Math.max(-1,Math.min(2,nc))+1.2*st};
{const nw=novo(),same=Math.abs(((nw.g0-g0)%B+B*1.5)%B-B/2)<.03&&((nw.drop<0&&drop<0)||(nw.drop>0&&drop>0&&Math.abs(nw.drop-drop)<.04));
if(!same){const so=verif(g0,drop),sn2=verif(nw.g0,nw.drop);if(sn2>so+.08){g0=nw.g0;drop=nw.drop}}}
return{bpm:Math.round(bpm*1000)/1000,g0:Math.round(g0*1000)/1000,drop:drop>0?Math.round(drop*1000)/1000:-1,conf:Math.round(bs*10)/10}}
/* Beats do SoundCloud: não temos o áudio, só a forma de onda (~1800 valores, um a cada ~0,1 s). Mesmo assim, ao longo de uns 200 batidas dá para achar o BPM exato e a fase.
   sm = amostras da forma de onda, dur = duração em s, opt.hint = BPM aproximado, opt.drop = virada achada (s) ou -1 */
function rimaWave(sm,dur,opt){
opt=opt||{};const n=sm&&sm.length;if(!(n>300)||!(dur>20))return null;
const sps=n/dur,r=new Float64Array(n);let m=0;
r[0]=sm[0]>0?sm[0]:0;m=r[0];for(let i=1;i<n;i++){const d=sm[i]-sm[i-1];if(d>0){r[i]=d;m+=d}}
m=m/n||1e-9;for(let i=0;i<n;i++)r[i]/=m;
const prior=opt.hint||100,sg=opt.hint?.35:.7,pw=bp=>Math.exp(-.5*Math.pow(Math.log2(bp/prior)/sg,2));
const sc=(bp,ph)=>{const P=60/bp;let s=0,c=0;for(let t=ph;t<dur-.3;t+=P){s+=r[Math.min(n-1,Math.floor(t*sps+1e-9))];c++}return s/(c||1)};
const best=(bp,ps)=>{const P=60/bp;let b=-1,bph=0;for(let ph=0;ph<P;ph+=ps){const v=sc(bp,ph);if(v>b){b=v;bph=ph}}return[b,bph]};
const co=[];for(let bp=60;bp<=150.001;bp+=.1){const[v,ph]=best(bp,.012);co.push([bp,v*pw(bp),ph])}
const pk=[];for(let i=0;i<co.length;i++){let ok=1;for(let d=-10;d<=10;d++){const j=i+d;if(j>=0&&j<co.length&&co[j][1]>co[i][1])ok=0}if(ok)pk.push(co[i])}
pk.sort((a,b)=>b[1]-a[1]);
let bpm=pk[0][0],ph=pk[0][2],bs=-1;
for(const[b0]of pk.slice(0,3)){let lb=b0,lp=0,ls=-1;for(let bp=b0-.1;bp<=b0+.1;bp+=.004){const[v,p]=best(bp,.004);const w=v*pw(bp);if(w>ls){ls=w;lb=bp;lp=p}}if(ls>bs){bs=ls;bpm=lb;ph=lp}}
{/* ajuste final: média da região de maior pontuação (evita escolher um degrau qualquer do platô) */
const P0=60/bpm,cand=[];let vm=-1;for(let bp=bpm-.08;bp<=bpm+.08;bp+=.002){const P=60/bp;for(let d=-.03;d<=.03;d+=.002){let p=ph+d;p=((p%P)+P)%P;const v=sc(bp,p);cand.push([bp,d,v]);if(v>vm)vm=v}}
let sw=0,sb=0,sd=0;for(const[bp,d,v]of cand){const w=Math.max(0,v-.93*vm);sw+=w;sb+=w*bp;sd+=w*d}
if(sw>0){bpm=sb/sw;const P=60/bpm;ph=(((ph+sd/sw)%P)+P)%P}}
const conf=sc(bpm,ph);if(conf<1.4)return null;
const P=60/bpm,B=4*P;
/* virada: primeiro ponto onde a música "enche" (energia das próximas 2 compassos bem maior que a das 2 anteriores), medida batida a batida */
const nb=Math.max(0,Math.floor((dur-ph)/P)-1),E=new Float64Array(nb);
for(let k=0;k<nb;k++){const a=Math.floor((ph+k*P)*sps),b=Math.min(n,Math.max(a+1,Math.floor((ph+(k+1)*P)*sps)));let t=0;for(let i=a;i<b;i++)t+=sm[i];E[k]=t/(b-a)}
const Es=Float64Array.from(E).sort(),G=Es[Math.floor(Es.length*.8)]||1,me=(a,b)=>{a=Math.max(0,a);b=Math.min(nb,b);if(b<=a)return 0;let t=0;for(let i=a;i<b;i++)t+=E[i];return t/(b-a)};
const kmax=Math.min(nb-8,Math.floor(90/P)),dn=new Float64Array(Math.max(0,kmax+1));let dM=0;
for(let k=4;k<=kmax;k++){const a=me(k,k+8),b=me(k-8,k);dn[k]=a<G*.4?0:(a-b)/G;if(dn[k]>dM)dM=dn[k]}
let dk=-1;
if(dM>=.12){const th=Math.max(.12,dM*.55);for(let k=4;k<=kmax;k++){if(dn[k]<th)continue;let j=k;while(j+1<=kmax&&dn[j+1]>=dn[j])j++;let bk=j,bv=-1e9;for(let q=Math.max(4,j-8);q<=Math.min(nb-4,j+4);q++){const v=me(q,q+4)-me(q-4,q);if(v>bv){bv=v;bk=q}}dk=bk;break}}
let D=-1;
if(dk>=0){/* o golpe mais forte na virada diz se a grade está na batida ou no contratempo */
let bi=Math.floor((ph+dk*P)*sps),bm=-1,bt=0;for(let i=Math.max(1,bi-Math.ceil(P*sps)-1);i<=Math.min(n-1,bi+Math.ceil(P*sps)+1);i++)if(r[i]>bm){bm=r[i];bt=(i+.5)/sps}D=bt}
else if(opt.drop>0)D=opt.drop;
if(D>0){const dist=p=>{const k=Math.round((D-p)/P);return Math.abs(D-(p+k*P))};const alt=(ph+P/2)%P;if(dist(alt)<dist(ph))ph=alt}
let g0,drop=-1;
if(D>0){const k=Math.round((D-ph)/P),db=ph+k*P;g0=((db%B)+B)%B;drop=db}
else{let f=0;for(let i=0;i<n;i++)if(r[i]>3&&sm[i]>0){f=i/sps;break}const k=Math.round((f-ph)/P);g0=(((ph+k*P)%B)+B)%B}
return{bpm:Math.round(bpm*1000)/1000,g0:Math.round(g0*1000)/1000,drop:drop>0?Math.round(drop*1000)/1000:-1,conf:Math.round(conf*10)/10}}

/* Virada pela "cheia" do beat: bumbo (grave) E caixa/chimbal (agudo) entram juntos e se mantêm. Mede compasso a compasso na grade já achada (g0) e pega o 1º compasso em que as duas faixas chegam a metade do nível normal da música por 4 compassos seguidos. Baixo/acorde sozinhos ou chimbal sozinho não contam. */
function rimaDrop(x,sr,bpm,g0,th){
const F=Math.max(1,Math.round(sr/11025)),sr2=sr/F,n2=Math.floor(x.length/F),hop=Math.max(8,Math.round(sr2*.012)),nf=Math.floor(n2/hop);
const B=240/bpm,a1=1-Math.exp(-2*Math.PI*150/sr2),L=new Float32Array(nf),Hh=new Float32Array(nf);let p1=0,p2=0;
for(let f=0;f<nf;f++){let el=0,eh=0;for(let i=0;i<hop;i++){let s=0;const b=(f*hop+i)*F;for(let k=0;k<F;k++)s+=x[b+k];s/=F;p1+=a1*(s-p1);p2+=a1*(p1-p2);const h=s-p1;el+=p2*p2;eh+=h*h}L[f]=Math.sqrt(el/hop);Hh[f]=Math.sqrt(eh/hop)}
const fb=hop/sr2,nb=Math.floor((nf*fb-g0)/B)-1;if(nb<12)return null;
const lf=new Float64Array(nb),hf=new Float64Array(nb);
for(let k=0;k<nb;k++){const a=Math.max(1,Math.floor((g0+k*B)/fb)),b=Math.min(nf,Math.floor((g0+(k+1)*B)/fb));let u=0,v=0;for(let f=a;f<b;f++){const d=L[f]-L[f-1],e=Hh[f]-Hh[f-1];if(d>0)u+=d;if(e>0)v+=e}lf[k]=u;hf[k]=v}
const q=A=>{const t=Float64Array.from(A).sort();return t[Math.floor(t.length*.75)]||1e-9},ql=q(lf),qh=q(hf),fu=new Float64Array(nb);
for(let k=0;k<nb;k++)fu[k]=Math.min(lf[k]/ql,hf[k]/qh);
th=th||.5;const kmax=Math.min(nb-4,Math.floor(100/B));
const mm=(a,b)=>{let t=0;for(let i=a;i<b;i++)t+=fu[i];return t/(b-a)};
for(let k=0;k<=kmax;k++){if(!(fu[k]>=th&&fu[k+1]>=th&&fu[k+2]>=th&&fu[k+3]>=th))continue;if(k>0){const pre=mm(Math.max(0,k-4),k),cur=mm(k,k+4);if(pre>.55*cur)continue}return{k:k,t:g0+k*B}}
return null}

/* Pista HARMÔNICA do tempo 1: acorde/baixo/sample trocam na virada do compasso (loops de boom bap, lo-fi, trap melódico). Não depende da bateria,
   então corrige o caso em que o bumbo é sincopado e a fase da bateria cai na batida ou no contratempo errado.
   Mede a troca de espectro (80 a 2000 Hz) entre 1 batida antes e 1 batida depois, em todo o áudio, dobra no tamanho de 1 compasso e acha o pico. */
function rimaHarm(x,sr,bpm){
const F=Math.max(1,Math.round(sr/11025)),s2=sr/F,N=2048,n2=Math.floor(x.length/F),P=60/bpm,B=4*P;if(n2<N*8)return null;
const y=new Float32Array(n2);for(let i=0;i<n2;i++){let t=0;for(let k=0;k<F;k++)t+=x[i*F+k];y[i]=t/F}
const lg=Math.log2(N),rev=new Uint16Array(N);for(let i=0;i<N;i++){let r=0;for(let b=0;b<lg;b++)if(i&(1<<b))r|=1<<(lg-1-b);rev[i]=r}
const cs=new Float64Array(N/2),sn=new Float64Array(N/2);for(let i=0;i<N/2;i++){cs[i]=Math.cos(2*Math.PI*i/N);sn[i]=-Math.sin(2*Math.PI*i/N)}
const NBd=40,lo=60,hi=2000,bf=[];for(let b=0;b<=NBd;b++)bf.push(Math.round(lo*Math.pow(hi/lo,b/NBd)*N/s2));
const hop=Math.max(256,Math.round(P/6*s2)),nfr=Math.floor((n2-N)/hop);if(nfr<16)return null;
const re=new Float64Array(N),im=new Float64Array(N),V=new Float64Array((nfr+1)*NBd);
for(let f=0;f<nfr;f++){const o=f*hop;for(let i=0;i<N;i++){const j=rev[i];re[j]=y[o+i]*(.5-.5*Math.cos(2*Math.PI*i/N));im[j]=0}
 for(let len=2;len<=N;len<<=1){const h=len>>1,st=N/len;for(let i=0;i<N;i+=len)for(let k=0;k<h;k++){const a=i+k,b=a+h,wr=cs[k*st],wi=sn[k*st],tr=re[b]*wr-im[b]*wi,ti=re[b]*wi+im[b]*wr;re[b]=re[a]-tr;im[b]=im[a]-ti;re[a]+=tr;im[a]+=ti}}
 let nr=0;const v=new Float64Array(NBd);for(let b=0;b<NBd;b++){let t=0,c=0;for(let k=bf[b];k<Math.max(bf[b]+1,bf[b+1]);k++){t+=Math.sqrt(re[k]*re[k]+im[k]*im[k]);c++}v[b]=Math.log(1+20*t/(c||1));nr+=v[b]*v[b]}
 nr=Math.sqrt(nr)||1;for(let b=0;b<NBd;b++)V[(f+1)*NBd+b]=V[f*NBd+b]*0+v[b]/nr}
/* soma acumulada por faixa (V guarda o quadro f em f+1; refaz como acumulado) */
const C=new Float64Array((nfr+1)*NBd);for(let f=0;f<nfr;f++)for(let b=0;b<NBd;b++)C[(f+1)*NBd+b]=C[f*NBd+b]+V[(f+1)*NBd+b];
const fs=hop/s2,cen=f=>(f*hop+N/2)/s2,fi=t=>Math.round((t*s2-N/2)/hop);
const mean=(a,b,o)=>{a=Math.max(0,a);b=Math.min(nfr,b);if(b-a<1)return null;for(let k=0;k<NBd;k++)o[k]=(C[b*NBd+k]-C[a*NBd+k])/(b-a);return o};
const NS=64,H=new Float64Array(NS),Hc=new Float64Array(NS),A=new Float64Array(NBd),Bv=new Float64Array(NBd),dt=P/8,g=Math.max(fs*1.2,.12*P);
const tEnd=n2/s2-P-N/s2;for(let t=P+N/2/s2;t<tEnd;t+=dt){const a=mean(fi(t-P),fi(t-g),A),b=mean(fi(t+g),fi(t+P),Bv);if(!a||!b)continue;let d=0,na=0,nb=0;for(let k=0;k<NBd;k++){d+=A[k]*Bv[k];na+=A[k]*A[k];nb+=Bv[k]*Bv[k]}const nv=1-d/Math.sqrt(na*nb||1);let p=t/B;p=(p-Math.floor(p))*NS;const sl=Math.floor(p)%NS;H[sl]+=nv;Hc[sl]++}
for(let i=0;i<NS;i++)H[i]=Hc[i]?H[i]/Hc[i]:0;
/* suaviza 3 casas e acha o pico; o pico precisa se destacar e não ter um irmão de meio compasso quase igual (2 acordes por compasso) */
const Sm=new Float64Array(NS);for(let i=0;i<NS;i++)Sm[i]=(H[(i+NS-1)%NS]+2*H[i]+H[(i+1)%NS])/4;
let pk=0;for(let i=1;i<NS;i++)if(Sm[i]>Sm[pk])pk=i;const sorted=Float64Array.from(Sm).sort(),med=sorted[NS>>1]||1e-9;
const half=Math.max(Sm[(pk+NS/2)%NS],Sm[(pk+NS/2+1)%NS],Sm[(pk+NS/2-1+NS)%NS]),qtr=Math.max(Sm[(pk+NS/4)%NS],Sm[(pk+3*NS/4)%NS]);
/* posição fina: centro de massa ao redor do pico */
let cw=0,cp=0;for(let d=-2;d<=2;d++){const w=Sm[(pk+d+NS)%NS];cw+=w;cp+=w*d}const ph=((pk+cp/cw+.5)/NS)*B;
return{ph:ph%B,conf:Sm[pk]/med,rel:half/Sm[pk],relq:qtr/Sm[pk]}}


/* Árbitro final do tempo 1: junta a pista harmônica (grossa, mas independente da bateria) com a do bumbo (fina). Só troca a grade da bateria quando
   a harmonia é clara (pico único, sem irmão de meio compasso) E o bumbo apoia bem mais a grade nova do que a antiga. */
function rimaFix(x,sr,a){
try{const h=rimaHarm(x,sr,a.bpm);if(!h||h.conf<2.4||h.rel>.55||h.relq>.8)return a;
const F=Math.max(1,Math.round(sr/11025)),s2=sr/F,n2=Math.floor(x.length/F),H=64,nf=Math.floor(n2/H),hs=H/s2,B=240/a.bpm,P=B/4;
const rl=new Float32Array(nf),a1=1-Math.exp(-2*Math.PI*150/s2);let lp=0;for(let i=0;i<nf;i++){let e=0;for(let k=0;k<H;k++){let v=0;for(let q=0;q<F;q++)v+=x[(i*H+k)*F+q];v/=F;lp+=a1*(v-lp);e+=lp*lp}rl[i]=Math.sqrt(e/H)}
const ol=new Float32Array(nf);for(let i=2;i<nf;i++)ol[i]=Math.max(0,rl[i]-(rl[i-1]+rl[i-2])/2);
const NS=256,f0=a.drop>0?Math.round(a.drop/hs):0,fold=new Float64Array(NS);for(let i=f0;i<nf;i++){let p=(i*hs)/B;p=(p-Math.floor(p))*NS;fold[Math.floor(p)%NS]+=ol[i]}
const at=(t)=>{let p=((t%B)+B)%B/B*NS,c=Math.round(p),s=0;for(let d=-2;d<=2;d++)s+=fold[((c+d)%NS+NS)%NS];return s};
/* candidato fino: o maior pico de bumbo dentro de ±0,25 batida da posição harmônica */
const c0=h.ph;let bt=-1,bv=-1;for(let d=-.25*P;d<=.25*P;d+=B/NS){const v=at(c0+d);if(v>bv){bv=v;bt=c0+d}}
const dd=(((bt-a.g0)%B)+B*1.5)%B-B/2; /* distância da grade antiga ao candidato (−B/2..B/2) */
if(Math.abs(dd)<.18*P)return a; /* concordam: mantém a antiga (mais fina) */
let tot=0,mx=0;for(let i=0;i<NS;i++){tot+=fold[i];if(fold[i]>mx)mx=fold[i]}
const strong=h.conf>=3.5&&h.rel<.3&&h.relq<.5;if(!(at(bt)>(strong?.8:1.35)*at(a.g0))||!(at(bt)>1.25*mx))return a;
const g0=((bt%B)+B)%B,d0=a.g0;let drop=a.drop;if(drop>0){let m=Math.round((drop-g0)/B);drop=g0+m*B}
return Object.assign({},a,{g0:g0,drop:drop>0?drop:a.drop,fix:1})}catch(e){return a}}

function rimaAnalyze(x,sr,opt){
const a=rimaAnalyze0(x,sr,opt);if(!a||!(a.bpm>0)||!(a.g0>=0))return a;
try{let d=null;for(const t of[.5,.35,.25]){d=rimaDrop(x,sr,a.bpm,a.g0,t);if(d)break}if(d&&d.k>=1)a.drop=Math.round(d.t*1000)/1000;else if(d&&d.k==0)a.drop=-1}catch(e){}
return rimaFix(x,sr,a)}
/*ANALYZER_END*/
if(typeof module!=='undefined')module.exports={rimaAnalyze,rimaWave,rimaHarm};
