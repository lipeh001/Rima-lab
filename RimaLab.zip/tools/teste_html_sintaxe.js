/* Valida a sintaxe dos scripts inline do HTML sem executar o aplicativo. */
const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/rima-lab.html', 'utf8');
const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)]
  .filter(([, attrs, body]) => !/\bsrc\s*=/i.test(attrs) && body.trim());
if (!scripts.length) throw new Error('Nenhum script inline encontrado.');
let failed = 0;
for (let i = 0; i < scripts.length; i++) {
  try {
    new Function(scripts[i][2]);
    console.log(`OK  script inline ${i + 1}: sintaxe válida`);
  } catch (error) {
    failed++;
    console.error(`FAIL script inline ${i + 1}: ${error.message}`);
  }
}
console.log(`${scripts.length - failed}/${scripts.length} scripts inline passaram`);
process.exit(failed ? 1 : 0);
