/* Teste DURO: beats sintéticos mais parecidos com beats reais (intro melódica, bateria entrando aos poucos, humanização, ruído, lo-fi, 808).  node tools/teste_duro.js [n] */
const {rimaAnalyze}=require('./analyzer.js');const SR=22050;
function rng(seed){let s=seed>>>0;return()=>((s=(s*1664525+1013904223)>>>0)/4294967296)}
const STY={bb:{k:[[0,6,10],[0,7,10],[0,6,10],[0,7,14]],sn:[4,12],h:2},trap:{k:[[0,10,11],[0,10],[0,7,10],[0,10,11,14]],sn:[8],h:1},drill:{k:[[0,6,10],[0,6,9],[0,6,10],[0,3,9]],sn:[8],h:1},lofi:{k:[[0,7],[0,7,10],[0,7],[0,7,11]],sn:[4,12],h:2},funk:{k:[[0,3,6,10],[0,3,6,10],[0,3,6,10],[0,3,6,12]],sn:[4,12],h:2}};
function synth(p){const {bpm,t0,intro,style,seed,mode,swing,jit,noise,lo,melInt,introKick,dur}=p,n=Math.floor(dur*SR),x=new Float32Array(n),r=rng(seed),P=60/bpm,bar=4*P,step=P/4,S=STY[style];
const add=(t,fn,len)=>{const i0=Math.floor(t*SR);for(let i=0;i<len&&i0+i<n;i++)if(i0+i>=0)x[i0+i]+=fn(i/SR)};
const f0=40+r()*25,kick=a=>t=>a*Math.sin(2*Math.PI*(f0*t+75*(1-Math.exp(-t*30))/30))*Math.exp(-t*8);
const snare=a=>t=>a*((r()*2-1)*.7+.5*Math.sin(2*Math.PI*190*t))*Math.exp(-t*20),hat=a=>t=>a*(r()*2-1)*Math.exp(-t*80);
const nbars=Math.floor((dur-t0)/bar),ch=[220,261.6,329.6,392,196,246.9,293.7,349.2];
for(let b=0;b<nbars;b++){const tb=t0+b*bar,full=b>=intro;
 /* melodia/acorde: troca a cada compasso (ou a cada 2), presente em toda a música, mais forte na intro quando melInt */
 const fr=ch[Math.floor(b/ (b%8<4?1:2))%ch.length],ma=(full?.07:(melInt?.16:.06));
 for(let i=0;i<bar*SR;i++){const j=Math.floor(tb*SR)+i;if(j<n){const tt=i/SR;x[j]+=ma*(Math.sin(2*Math.PI*fr*tt)+.5*Math.sin(2*Math.PI*fr*1.5*tt)+.3*Math.sin(2*Math.PI*fr*2*tt))*(1-.3*Math.exp(-tt*3))}}
 /* progressão da bateria na intro: mode0 nada; mode1 hat desde o começo; mode2 hat+caixa nos últimos 2 compassos; mode3 só kick fraco em compassos ímpares */
 for(let s=0;s<16;s++){let ts=tb+s*step+((s%2)?swing*step:0)+(r()-.5)*2*jit;
  if(full){const ks=S.k[b%4];if(ks.indexOf(s)>=0)add(ts,kick(s==0?1:.8),SR*.35);if(S.sn.indexOf(s)>=0)add(ts,snare(.65),SR*.2);if(s%S.h==0)add(ts,hat(.13),SR*.05)}
  else{if(mode>=1&&s%S.h==0)add(ts,hat(.07),SR*.05);if(mode==2&&b>=intro-2&&S.sn.indexOf(s)>=0)add(ts,snare(.3),SR*.2);if(mode==3&&introKick&&s==0&&b%2==0)add(ts,kick(.3),SR*.3);if(mode==4&&b>=intro-2&&s==0)add(ts,kick(.55),SR*.3)}}
 /* 808 sustentado só no beat cheio */ if(full)for(let i=0;i<bar*SR*.5;i++){const j=Math.floor(tb*SR)+i;if(j<n)x[j]+=.12*Math.sin(2*Math.PI*f0*i/SR)*Math.exp(-i/SR*2)}}
for(let i=0;i<n;i++)x[i]+=noise*(r()*2-1);
if(lo){let y=0;for(let i=0;i<n;i++){y+=.35*(x[i]-y);x[i]=y}}
return x}
function mk(N){const R=rng(+process.env.SEED||777),L=[],ks=Object.keys(STY);for(let i=0;i<N;i++)L.push({style:ks[Math.floor(R()*ks.length)],bpm:Math.round((70+R()*80)*100)/100,t0:Math.round(R()*2.5*1000)/1000,intro:[0,1,2,4,4,8,8,16][Math.floor(R()*8)],seed:i+3,mode:Math.floor(R()*5),swing:R()<.3?.12:0,jit:R()<.5?.008:.002,noise:R()<.5?.02:.004,lo:R()<.25,melInt:R()<.5,introKick:R()<.5,dur:80+Math.floor(R()*50)});return L}
const N=+process.argv[2]||60,cs=mk(N);let ok=0,bad=0,vir=0;const f=[];
for(const p of cs){const x=synth(p),bar=240/p.bpm,T1=p.t0+p.intro*bar;
 let a=null;try{a=rimaAnalyze(x,SR,{hint:Math.round(p.bpm*(0.94+((p.seed*37)%13)/100))})}catch(e){}
 if(!a){bad++;f.push([p,'sem resultado']);continue}
 const g=a.g0,k=((g-T1)/bar),kr=k-Math.round(k),e1=Math.abs(a.bpm-p.bpm)/p.bpm;
 const dr=a.drop>0?a.drop:g+0; /* tempo 1 verdadeiro = T1 (primeiro compasso do beat cheio) */
 const t1=a.drop>0?a.drop:-1,err=t1>0?(t1-T1)/bar:null;
 const good=e1<.004&&Math.abs(kr)<.03&&(p.intro==0?(t1<0||Math.abs(err)<.06):(t1>0&&Math.abs(err)<.06));
 if(good)ok++;else f.push([JSON.stringify(p),'bpm '+a.bpm+' fase '+(kr*bar*1000).toFixed(0)+'ms drop '+(t1>0?err.toFixed(2)+' comp':'nenhum')])}
console.log('OK',ok,'/',N);f.slice(0,25).forEach(x=>console.log(' ERRO',x.join(' -> ')))
