const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/rima-lab.html', 'utf8');
const main = fs.readFileSync('app/src/main/java/app/rimalab/MainActivity.java', 'utf8');
const service = fs.readFileSync('app/src/main/java/app/rimalab/MusicService.java', 'utf8');
const checks = [
  ['wizard uses modo in the visible title', html.includes('Escolha o modo') && !html.includes('Escolha o módulo') && html.includes('id="md"')],
  ['wizard has configuration step', html.includes('id="train-step-2"') && html.includes('function trainNext()')],
  ['wizard has back navigation', html.includes('function trainBack()')],
  ['calibration can be skipped from one dedicated panel', html.includes('A sincronização é opcional') && html.includes('Começar treino') && html.includes('calHTML()')],
  ['words module is first', html.indexOf("['pal','Palavras'") < html.indexOf("['atq','Batalhar contra o app'")],
  ['module-specific options renderer', html.includes("if(m==='atq')") && html.includes("if(m==='lig')")],
  ['app battle has seconds/compassos selector', html.includes("chips('su'") && html.includes("CH.su=='c'?CH.sv:0")],
  ['app battle counts user bars', html.includes("S.phase==='user'&&S.U")],
  ['notification permission is not requested on launch', !main.split('protected void onCreate')[1].split('protected void onBackPressed')[0].includes('pedirNotifUi();')],
  ['notification only starts while playing', main.includes('if (st <= 0)')],
  ['permission grant refreshes notification state', main.includes('rimaNotifGranted') && html.includes('window.rimaNotifGranted')],
  ['new media notification channel', service.includes('rimalab_player_v2')],
  ['word-entry animation no longer blurs', html.includes('@keyframes rl-word-crisp') && html.includes('.stage.hit .word{animation:rl-word-crisp')],
  ['visual beat flash is disabled', html.includes('.stage::after{display:none!important')],
  ['CSS style tags are balanced', (html.match(/<style\b/gi)||[]).length === (html.match(/<\/style>/gi)||[]).length],
  ['CSS style blocks are not nested', (()=>{const tags=[...html.matchAll(/<\/?style\b[^>]*>/gi)];let d=0,ok=true;for(const t of tags){if(/^<\/style/i.test(t[0])){if(d!==1)ok=false;d--}else{if(d!==0)ok=false;d++}}return ok&&d===0})()],
  ['final word/player overrides are inside a style block', (()=>{const o=html.lastIndexOf('<style');const c=html.indexOf('</style>',o);return o>=0&&c>o&&html.indexOf('rl-word-crisp',o)<c&&html.indexOf('#pbar .pw-art span',o)<c})()],
  ['player logo RL and equalizer have separate positions', html.includes('#pbar .pw-art span{position:absolute') && html.includes('#pbar .pw-art i{position:absolute')],
  ['Jamendo queries cover battle/freestyle/cypher', html.includes('battle rap instrumental') && html.includes('freestyle rap beat instrumental') && html.includes('cypher hip hop instrumental')],
  ['Boom bap search includes Aldeia and Zona Norte descriptors', html.includes('batalha da aldeia beat instrumental') && html.includes('zona norte batalha de rima beat')],
  ['Jamendo catalog capped at 50 per style', html.includes('ZLIB[st][1]=L.slice(0,50)') && html.includes('picked.length>=50')],
  ['randomizer spans all three styles', html.includes('Sortear beat entre Boom bap, Trap e Drill') && html.includes('function zMixPick()') && html.includes('styles.forEach(st=>')],
  ['player shuffle is cross-genre from any current source', html.includes('if(ZS.shuf){zMixPick();return}')],
  ['randomizer waits for all styles before picking', html.includes('function zMixCheck()') && html.includes('ZMixWait=1')],
  ['Jamendo track and licence backlink shown', html.includes("Jamendo · ${esc(x[8]||'ver licença')}") && html.includes('zJmTrackUrl')],
  ['Jamendo stream field is used instead of download-only field', html.includes('r.audio&&(+r.duration||0)') && html.includes('return [r.audio')],
  ['Jamendo offline save respects audiodownload_allowed', html.includes('audiodownload_allowed===true') && html.includes('perm=allowed?1:0') && main.includes('getFilesDir(), \"beats\"')],
  ['Jamendo free-text searches use the official search parameter', html.includes('const param=q[0];') && !html.includes("q[0]=='search'?'namesearch':q[0]")],
  ['catalog is requested during splash startup', html.includes('bhome();init();') && html.includes('Object.keys(ZLIB).forEach(st=>zJm(st))') && html.includes('window.rimaCatalogReady')],
  ['splash waits for catalog result or timeout', html.includes('Promise.all([Promise.race([fonts') && html.includes('catalog])')],
  ['one calibration component per screen', (html.match(/calHTML\(\)/g)||[]).length===3 && !html.includes('Calibrar áudio')],
  ['app battle description reflects configurable setup', html.includes('Configure quantos rounds quer jogar') && !html.includes('O app ataca por 4 compassos')],
  ['Jamendo results use a 12-hour local catalog TTL', html.includes('const ZCACHE_MS=12*60*60*1000') && html.includes('function zCacheFresh(st)')],
  ['offline fallback beat remains selectable', html.includes('Beat de segurança · offline') && html.includes('zSyn(ALW[0])') && html.includes("ZS.k!='syn'&&!ZS.key")],
  ['permanent beats are restored from native saved list', html.includes('RimaNative.lista()') && html.includes('ZLOCAL.has(k)') && main.includes('getFilesDir(), \"beats\"')],
  ['training stage falls back to an internal beat if remote audio fails', html.includes('zFallback(\'Esse beat não abriu. Iniciei uma base do Rima Lab')],
  ['training start protects against player initialization errors', html.includes('function lvStart(){') && html.includes('catch(e){try{zFallback(')],
  ['startup requests all three Jamendo styles', html.includes("['Boom bap','Trap','Drill'].forEach(st=>")],
  ['daily feedback has multiple time-based messages', html.includes('function stat(){') && html.includes('mins<5?') && html.includes('mins<15?') && html.includes('mins<30?')],
  ['training start CTA is separated from calibration help', html.includes('class=\"training-footer\"') && html.includes('border-top:1px solid rgba(255,255,255,.10)')],
];
let fail = 0;
for (const [name, ok] of checks) { console.log((ok ? 'OK  ' : 'FAIL') + name); if (!ok) fail++; }
console.log(`${checks.length - fail}/${checks.length} checks passed`);
process.exit(fail ? 1 : 0);
