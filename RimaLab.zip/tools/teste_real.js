/* Teste "mais real": baixo e acordes na introdução (sem bumbo), bumbo sincopado, caixa no 2 e 4 ou só no 3. node tools/teste_real.js 60 */
const {rimaAnalyze}=require(process.env.AN||'./analyzer.js');const SR=22050;
function rng(seed){let s=seed>>>0;return()=>((s=(s*1664525+1013904223)>>>0)/4294967296)}
const KP=[[[0,6,10],[0,7,10],[0,6,10],[0,7,14]],[[0,10],[0,8,10],[10],[0,8,11]],[[0,3,10],[0,10],[0,3,10],[10,14]]];
function synth(p){const n=Math.floor(p.dur*SR),x=new Float32Array(n),r=rng(p.seed),P=60/p.bpm,bar=4*P,st=P/4,ch=[[0,4,7],[5,9,12],[7,11,14],[3,7,10]],root=40+Math.floor(r()*8),half=p.half;
const add=(t,len,fn)=>{const i0=Math.floor(t*SR);for(let i=0;i<len&&i0+i<n;i++)if(i0+i>=0)x[i0+i]+=fn(i/SR)};
const nb=Math.floor((p.dur-p.t0)/bar);
for(let b=0;b<nb;b++){const tb=p.t0+b*bar,full=b>=p.intro,c=ch[Math.floor(b/ (p.chordBars||1))%4],hz=m=>440*Math.pow(2,(m-69)/12);
 for(const m of c)add(tb,bar*SR,t=>.045*Math.sin(2*Math.PI*hz(root+12+m)*t)*Math.min(1,t*8)*(.85+.15*Math.cos(Math.PI*t/bar)));
 const bassOn=full||p.introType>=1;
 if(bassOn){const pos=full?[0,10]:p.bassPos;for(const s of pos)add(tb+s*st,SR*.5,t=>.22*Math.sin(2*Math.PI*hz(root+c[0]-12)*t)*Math.exp(-t*3.5)*Math.min(1,t*200))}
 for(let s=0;s<16;s++){const t=tb+s*st+((s&1)&&p.sw?p.sw*st:0);
  if((full||p.introType>=2)&&s%2==0)add(t,SR*.04,u=>(full?.12:.06)*(r()*2-1)*Math.exp(-u*100));
  if(full){if(KP[p.kp][b%4].indexOf(s)>=0)add(tb+s*st,SR*.3,u=>(s==0?1:.8)*Math.sin(2*Math.PI*(42*u+70*(1-Math.exp(-u*30))/30))*Math.exp(-u*9));
   if((half?[8]:[4,12]).indexOf(s)>=0)add(tb+s*st,SR*.2,u=>.7*((r()*2-1)*.8+.5*Math.sin(2*Math.PI*190*u))*Math.exp(-u*22))}
  else if(p.introType==3&&b==p.intro-1&&s%2==1)add(t,SR*.05,u=>(.1+.5*s/16)*(r()*2-1)*Math.exp(-u*40))}}
for(let i=0;i<n;i++)x[i]+=.004*(r()*2-1);return x}
const R=rng(777),N=+process.argv[2]||60,fails=[];let ok=0;const V=[];
for(let i=0;i<N;i++){const p={bpm:Math.round((70+R()*80)*100)/100,t0:Math.round(R()*1.5*1000)/1000,intro:[0,2,4,4,8,8][Math.floor(R()*6)],kp:Math.floor(R()*3),half:R()<.4,sw:R()<.5?.15:0,dur:70,seed:i+3,chordBars:R()<.5?1:2};
 p.introType=p.intro?Math.floor(R()*4):0;p.bassPos=[[8],[8,14],[6,12],[0,8]][Math.floor(R()*4)];
 const P=60/p.bpm,bar=4*P,T1=p.t0+p.intro*bar,a=rimaAnalyze(synth(p),SR,{hint:0});let good=false,why='sem resultado';
 if(a){const dph=((a.g0-(T1%bar))%bar+bar*1.5)%bar-bar/2,dbpm=Math.abs(a.bpm-p.bpm);
  if(p.intro==0){good=dbpm<.1&&Math.abs(dph)<.04;why='fase '+(dph/P).toFixed(2)+' batidas'}
  else{good=dbpm<.1&&a.drop>0&&Math.abs(a.drop-T1)<.04;why=a.drop>0?'virada '+((a.drop-T1)/P).toFixed(2)+' batidas, fase '+(dph/P).toFixed(2):'sem virada'}}
 V.push(good?1:0);if(good)ok++;else fails.push(JSON.stringify({bpm:p.bpm,intro:p.intro,tipo:p.introType,kp:p.kp,half:p.half})+' -> '+why)}
if(process.env.VEC)console.log(V.join(''));console.log('OK '+ok+' / '+N);fails.slice(0,12).forEach(f=>console.log(' ERRO',f));
