/* Teste do tempo 1 (primeiro bumbo depois da virada) com beats sintéticos variados.  node tools/teste_tempo1.js [quantidade] */
const {rimaAnalyze}=require('./analyzer.js');
const SR=22050;
function rng(seed){let s=seed>>>0;return()=>((s=(s*1664525+1013904223)>>>0)/4294967296)}
/* estilos: padrão do bumbo em 16 passos para os 4 compassos do ciclo; caixa; hat */
const STY={
 bb:{k:[[0,6,10],[0,7,10],[0,6,10],[0,7,14]],sn:[4,12],h:2},
 trap:{k:[[0,10,11],[0,10],[0,7,10],[0,10,11,14]],sn:[8],h:1,half:1},
 drill:{k:[[0,6,10],[0,6,9],[0,6,10],[0,3,9]],sn:[8],h:1,half:1},
 funk:{k:[[0,3,6,10],[0,3,6,10],[0,3,6,10],[0,3,6,12]],sn:[4,12],h:2},
 pop:{k:[[0,8],[0,8],[0,8],[0,8,14]],sn:[4,12],h:2}
};
function synth(p){
const {bpm,t0,intro,riser,gap,dur,style,seed,kickIntro}=p,n=Math.floor(dur*SR),x=new Float32Array(n),r=rng(seed||1),P=60/bpm,bar=4*P,step=P/4,S=STY[style];
const add=(t,fn,len)=>{const i0=Math.floor(t*SR);for(let i=0;i<len&&i0+i<n;i++)if(i0+i>=0)x[i0+i]+=fn(i/SR)};
const kick=a=>t=>a*Math.sin(2*Math.PI*(45*t+75*(1-Math.exp(-t*30))/30))*Math.exp(-t*9);
const snare=a=>t=>a*((r()*2-1)*.8+.5*Math.sin(2*Math.PI*190*t))*Math.exp(-t*22);
const hat=a=>t=>a*(r()*2-1)*Math.exp(-t*90);
const nbars=Math.floor((dur-t0)/bar);
for(let b=0;b<nbars;b++){const tb=t0+b*bar,full=b>=intro,inRiser=!full&&b>=intro-riser-gap&&b<intro-gap,inGap=!full&&b>=intro-gap;
 for(let s=0;s<16;s++){const t=tb+s*step;
  if(full){const ks=S.k[b%4];if(ks.indexOf(s)>=0)add(t,kick(s==0?1:.8),SR*.35);if(S.sn.indexOf(s)>=0)add(t,snare(.7),SR*.2)}
  else if(kickIntro&&!inGap&&s==0&&b%2==0)add(t,kick(.25),SR*.3);
  if(!inGap&&s%S.h==0)add(t,hat(full?.14:.07),SR*.05);
  if(inRiser&&s%2==1)add(t,snare(.08+.6*((b-(intro-riser-gap))*16+s)/(riser*16)),SR*.06); /* rufo/caixa crescendo */
 }
 const f=full?55:(inGap?0:110),amp=full?.16:(inRiser?.07+.1*(b-(intro-riser-gap)+1)/riser:.05);
 if(f>0)for(let i=0;i<bar*SR;i++){const j=Math.floor(tb*SR)+i;if(j<n)x[j]+=amp*Math.sin(2*Math.PI*f*i/SR)}
 if(inGap&&gap&&b==intro-gap)add(tb,t=>.5*(r()*2-1)*Math.exp(-t*6),SR*.9); /* crash antes do silêncio */
}
return x}
function mkCases(N){const R=rng(12345),L=[],ks=Object.keys(STY);
for(let i=0;i<N;i++){const style=ks[Math.floor(R()*ks.length)],bpm=Math.round((72+R()*76)*100)/100,intro=[0,2,4,4,8,8][Math.floor(R()*6)];
 const riser=intro>=2?[0,1,2,2][Math.floor(R()*4)]:0,gap=intro>=2&&R()<.35?1:0;
 L.push({style,bpm,t0:Math.round(R()*1.2*1000)/1000,intro,riser:Math.min(riser,intro-gap),gap,kickIntro:intro>0&&R()<.3?1:0,dur:90+Math.floor(R()*40),seed:i+7})}
return L}
const N=+process.argv[2]||40,cases=mkCases(N);let ok=0,bad=0;const fails=[];
for(const p of cases){const x=synth(p),P=60/p.bpm,bar=4*P,T1=p.t0+p.intro*bar;
 const a=rimaAnalyze(x,SR,{hint:0});
 if(!a){bad++;fails.push([p,'sem resultado']);continue}
 /* o tempo 1 do treino é a virada (drop); sem introdução vale g0 */
 const got=a.drop>0?a.drop:null;let good,why='';
 const dbpm=Math.abs(a.bpm-p.bpm);
 const dph=((a.g0-(T1%bar))%bar+bar*1.5)%bar-bar/2;
 if(p.intro==0){good=dbpm<.05&&Math.abs(dph)<.03;why='fase '+(dph*1000|0)+' ms'}
 else{const e=got==null?null:(got-T1)/bar;good=dbpm<.05&&got!=null&&Math.abs(got-T1)<.03;why=got==null?'sem virada':'virada '+(e>=0?'+':'')+e.toFixed(2)+' compassos do 1º bumbo'}
 if(good)ok++;else{bad++;fails.push([p,why+' | bpm '+a.bpm+' (certo '+p.bpm+')'])}}
console.log('OK '+ok+' / '+N);
for(const[f,w]of fails.slice(0,25))console.log(' ERRO',JSON.stringify(f).replace(/"/g,''),'->',w);
process.exit(bad?1:0);
