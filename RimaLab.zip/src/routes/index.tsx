import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <iframe className="rima-frame" title="Rima Lab" src="/rima-lab.html" />;
}
