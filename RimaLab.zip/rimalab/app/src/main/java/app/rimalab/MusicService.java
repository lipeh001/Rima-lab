package app.rimalab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;

/** Notificação do beat: mantém o app vivo em segundo plano e tem o botão de pausar/tocar. */
public class MusicService extends Service {
    static final String CH = "rimalab_player";
    static final String A_PLAY = "app.rimalab.PLAY", A_PAUSE = "app.rimalab.PAUSE", A_STOP = "app.rimalab.STOP", A_PREV = "app.rimalab.PREV", A_NEXT = "app.rimalab.NEXT";
    static final int ID = 7;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        String a = in == null ? null : in.getAction();
        if (A_PLAY.equals(a)) { MainActivity.remote("play"); return START_NOT_STICKY; }
        if (A_PAUSE.equals(a)) { MainActivity.remote("pause"); return START_NOT_STICKY; }
        if (A_PREV.equals(a)) { MainActivity.remote("prev"); return START_NOT_STICKY; }
        if (A_NEXT.equals(a)) { MainActivity.remote("next"); return START_NOT_STICKY; }
        if (A_STOP.equals(a)) {
            MainActivity.remote("pause");
            stopForeground(true); stopSelf();
            return START_NOT_STICKY;
        }
        boolean playing = in != null && in.getIntExtra("st", 0) == 1;
        String title = in != null ? in.getStringExtra("title") : null;
        if (title == null || title.length() == 0) title = "Rima Lab";
        Notification n = build(playing, title);
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(ID, n);
        return START_NOT_STICKY;
    }

    private PendingIntent act(String action, int code) {
        Intent i = new Intent(this, MusicService.class).setAction(action);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification build(boolean playing, String title) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel c = new NotificationChannel(CH, "Beat tocando", NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action main = new Notification.Action.Builder(
                Icon.createWithResource(this, playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                playing ? "Pausar" : "Tocar", act(playing ? A_PAUSE : A_PLAY, 1)).build();
        Notification.Action close = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "Fechar", act(A_STOP, 2)).build();
        Notification.Action prev = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_previous), "Anterior", act(A_PREV, 3)).build();
        Notification.Action next = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_next), "Próximo", act(A_NEXT, 4)).build();
        return new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat_beat)
                .setColor(0xFF8F7BFF)
                .setLargeIcon(art())
                .setContentTitle(title)
                .setContentText(playing ? "Tocando agora" : "Pausado")
                .setSubText("Rima Lab")
                .setContentIntent(pi)
                .setOnlyAlertOnce(true)
                .setOngoing(playing)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(prev).addAction(main).addAction(next).addAction(close)
                .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
                .build();
    }

    /** Capa do beat: quadrado arredondado em degradê roxo com barras de onda sonora. */
    private Bitmap art() {
        int s = 256;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, s, s, 0xFF8F7BFF, 0xFF2A1B7A, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, s, s), 56, 56, p);
        p.setShader(null);
        p.setColor(0xFFC6FF3D);
        float[] h = {.28f, .5f, .78f, .42f, .64f, .34f};
        float w = 20, gap = 14, x = (s - (6 * w + 5 * gap)) / 2;
        for (int i = 0; i < 6; i++) {
            float hh = s * h[i];
            c.drawRoundRect(new RectF(x, (s - hh) / 2, x + w, (s + hh) / 2), 10, 10, p);
            x += w + gap;
        }
        return b;
    }
}
