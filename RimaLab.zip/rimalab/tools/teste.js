/* Testes do analisador com beats sintéticos de resposta conhecida.  node tools/teste.js */
const {rimaAnalyze}=require('./analyzer.js');
const SR=44100;
function rng(seed){let s=seed>>>0;return()=>((s=(s*1664525+1013904223)>>>0)/4294967296)*2-1}
function synth({bpm,t0,intro,dur,style,seed}){
const n=Math.floor(dur*SR),x=new Float32Array(n),r=rng(seed||1),P=60/bpm,bar=4*P,step=P/4;
const add=(t,fn,len)=>{const i0=Math.floor(t*SR);for(let i=0;i<len&&i0+i<n;i++)if(i0+i>=0)x[i0+i]+=fn(i/SR)};
const kick=a=>t=>a*Math.sin(2*Math.PI*(45*t+75*(1-Math.exp(-t*30))/30))*Math.exp(-t*9);
const snare=a=>t=>a*((r()*.8)+.5*Math.sin(2*Math.PI*190*t))*Math.exp(-t*22);
const hat=a=>t=>a*r()*Math.exp(-t*90);
const nbars=Math.floor((dur-t0)/bar);
for(let b=0;b<nbars;b++){const tb=t0+b*bar,full=b>=intro;
 for(let s=0;s<16;s++){const t=tb+s*step;
  if(style=='trap'){ if(full){if(s==0||s==10||s==11)add(t,kick(.9),SR*.4);if(s==8)add(t,snare(.8),SR*.25)} add(t,hat(s%2?.12:.2),SR*.06)}
  else{ if(full){const al=b%2;if(s==0||s==(al?7:6)||(s==10&&!al)||(s==14&&b%4==3))add(t,kick(s==0?1:.8),SR*.4);if(s==4||s==12)add(t,snare(.7),SR*.25)} if(s%2==0)add(t,hat(.12),SR*.06)}
 }
 /* base/pad que muda no compasso 1 do trecho cheio */
 const f=full?55:110;for(let i=0;i<bar*SR;i++){const j=Math.floor(tb*SR)+i;if(j<n)x[j]+=(full?.18:.05)*Math.sin(2*Math.PI*f*i/SR)}
}
return x}
const cases=[
{nome:'boom bap 92.37, intro 4 compassos',p:{bpm:92.37,t0:.43,intro:4,dur:110,style:'bb',seed:3},hint:92},
{nome:'trap meio-tempo 140.2, intro 2',p:{bpm:140.2,t0:.1,intro:2,dur:100,style:'trap',seed:5},hint:140},
{nome:'sem introdução 87.5',p:{bpm:87.5,t0:0,intro:0,dur:90,style:'bb',seed:7},hint:0},
{nome:'silêncio inicial 100, intro 8',p:{bpm:100,t0:.9,intro:8,dur:120,style:'bb',seed:9},hint:0}];
let bad=0;
for(const c of cases){const x=synth(c.p),t=Date.now(),a=rimaAnalyze(x,SR,{hint:c.hint||0,onsetBias:process.env.BIAS==null?undefined:+process.env.BIAS}),ms=Date.now()-t;
const P=60/c.p.bpm,bar=4*P,g0=c.p.t0%bar,drop=c.p.intro>0?c.p.t0+c.p.intro*bar:-1;
const dd=(a.g0-g0+bar*1.5)%bar-bar/2; /* erro da fase em s */
const eb=a.bpm-c.p.bpm,ed=drop>0?a.drop-drop:null;
const ok=Math.abs(eb)<.03&&Math.abs(dd)<.02&&(drop<0?a.drop<0||true:Math.abs(ed)<.02);
if(!ok)bad++;
console.log((ok?'OK  ':'ERRO')+' '+c.nome+'\n   achou bpm='+a.bpm+' g0='+a.g0+' virada='+a.drop+' conf='+a.conf+' ('+ms+' ms)\n   certo bpm='+c.p.bpm+' g0='+g0.toFixed(3)+' virada='+(drop>0?drop.toFixed(3):'nenhuma')+'   erro: bpm '+eb.toFixed(3)+', fase '+(dd*1000).toFixed(1)+' ms'+(ed!=null?', virada '+(ed*1000).toFixed(1)+' ms':''))}
process.exit(bad?1:0);
