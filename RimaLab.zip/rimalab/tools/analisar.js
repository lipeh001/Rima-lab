#!/usr/bin/env node
/* Mede todos os beats de app/src/main/assets/beats (mp3, ogg, wav, m4a) e grava beats/manifest.json.
   O app faz a MESMA medida sozinho se o manifest não tiver o beat; este script serve para conferir e para o beat abrir mais rápido.
   Uso:  node tools/analisar.js        (precisa do ffmpeg instalado) */
const fs=require('fs'),path=require('path'),cp=require('child_process');
const {rimaAnalyze}=require('./analyzer.js');
const dir=path.join(__dirname,'..','app','src','main','assets','beats'),SR=44100;
const HINT=t=>/^(honest|credit|trap|broad|melodic|one-life)/.test(t)?(t=='honest'?132:140):92; /* mesmo palpite da lista do app */
const man={},rows=[];
for(const f of fs.readdirSync(dir).sort()){if(!/\.(mp3|ogg|wav|m4a)$/i.test(f))continue;
const key=f.replace(/\.[^.]+$/,'');
const r=cp.spawnSync('ffmpeg',['-v','error','-i',path.join(dir,f),'-ac','1','-ar',String(SR),'-f','f32le','-'],{maxBuffer:1<<30});
if(r.status!==0){console.log('ERRO ao ler',f,String(r.stderr).slice(0,200));continue}
const b=r.stdout,x=new Float32Array(b.buffer,b.byteOffset,Math.floor(b.length/4));
const a=rimaAnalyze(x,SR,{hint:HINT(key)});
if(!a){console.log('sem resultado para',f);continue}
const dur=Math.round(x.length/SR*100)/100;man[key]=Object.assign({dur},a);
rows.push([key,a.bpm,a.g0,a.drop,a.conf,dur])}
fs.writeFileSync(path.join(dir,'manifest.json'),JSON.stringify(man,null,1));
console.log('beat'.padEnd(18),'BPM'.padEnd(9),'tempo 1 (s)'.padEnd(12),'virada (s)'.padEnd(11),'confianca  duracao');
for(const r of rows)console.log(String(r[0]).padEnd(18),String(r[1]).padEnd(9),String(r[2]).padEnd(12),String(r[3]).padEnd(11),String(r[4]).padEnd(10),r[5]);
console.log(rows.length+' beat(s) medidos -> beats/manifest.json');
