/* Simula a forma de onda do SoundCloud (pico por balde, 1800 baldes, 0..140) a partir de beats sintéticos e confere o resultado. */
const {rimaWave}=require('./analyzer.js');const SR=22050;
function rng(seed){let s=seed>>>0;return()=>((s=(s*1664525+1013904223)>>>0)/4294967296)*2-1}
function synth({bpm,t0,intro,dur,style,seed}){const n=Math.floor(dur*SR),x=new Float32Array(n),r=rng(seed),P=60/bpm,bar=4*P,step=P/4;
const add=(t,fn,len)=>{const i0=Math.floor(t*SR);for(let i=0;i<len&&i0+i<n;i++)if(i0+i>=0)x[i0+i]+=fn(i/SR)};
const kick=a=>t=>a*Math.sin(2*Math.PI*(45*t+75*(1-Math.exp(-t*30))/30))*Math.exp(-t*9),snare=a=>t=>a*((r()*.8)+.5*Math.sin(2*Math.PI*190*t))*Math.exp(-t*22),hat=a=>t=>a*r()*Math.exp(-t*90);
for(let b=0;b<Math.floor((dur-t0)/bar);b++){const tb=t0+b*bar,full=b>=intro;for(let s=0;s<16;s++){const t=tb+s*step;
if(style=='trap'){if(full){if(s==0||s==10||s==11)add(t,kick(.9),SR*.4);if(s==8)add(t,snare(.8),SR*.25)}add(t,hat(s%2?.12:.2),SR*.06)}
else{if(full){const al=b%2;if(s==0||s==(al?7:6)||(s==10&&!al)||(s==14&&b%4==3))add(t,kick(s==0?1:.8),SR*.4);if(s==4||s==12)add(t,snare(.7),SR*.25)}if(s%2==0)add(t,hat(.12),SR*.06)}}
const f=full?55:110;for(let i=0;i<bar*SR;i++){const j=Math.floor(tb*SR)+i;if(j<n)x[j]+=(full?.18:.05)*Math.sin(2*Math.PI*f*i/SR)}}return x}
function wave(x,dur,mode){const N=1800,per=x.length/N,o=[];const r=rng(99);for(let i=0;i<N;i++){let m=0;for(let k=Math.floor(i*per);k<Math.floor((i+1)*per);k++)m=Math.max(m,Math.abs(x[k]));o.push(m)}
const mx=Math.max(...o);return o.map(v=>{let q=v/mx;if(mode=='sqrt')q=Math.sqrt(q);if(mode=='noisy')q=Math.sqrt(q)*(1+.08*r());return Math.round(Math.min(1,q)*140)})}
const cases=[['boom bap 92.37 intro4',{bpm:92.37,t0:.43,intro:4,dur:150,style:'bb',seed:3},92],['trap 140.2 intro2',{bpm:140.2,t0:.1,intro:2,dur:150,style:'trap',seed:5},140],['bb 87.5 sem intro',{bpm:87.5,t0:0,intro:0,dur:170,style:'bb',seed:7},92],['bb 100 t0 .9 intro8',{bpm:100,t0:.9,intro:8,dur:180,style:'bb',seed:9},92],['bb 95.8 intro 8 t0 .2',{bpm:95.8,t0:.2,intro:8,dur:200,style:'bb',seed:11},92],['trap 132 intro4',{bpm:132,t0:.05,intro:4,dur:160,style:'trap',seed:13},132]];
let bad=0;
for(const mode of ['linear','sqrt','noisy'])for(const [nome,p,hint] of cases){const x=synth(p),sm=wave(x,p.dur,mode);
const P=60/p.bpm,B=4*P,truthDrop=p.intro>0?p.t0+p.intro*B:-1;
/* a virada que o app acharia: erro de até ~0,1 s para mais ou para menos */
const Din=truthDrop>0?truthDrop+(mode=='linear'?-.06:.08):-1;
const a=rimaWave(sm,p.dur,{hint,drop:process.env.ND?-1:Din});
if(!a){console.log('ERRO',mode,nome,'sem resultado');bad++;continue}
const g0=p.t0%B,dd=((a.g0-g0+B*1.5)%B)-B/2,eb=a.bpm-p.bpm,ed=truthDrop>0?a.drop-truthDrop:0;
const ok=Math.abs(eb)<.05&&Math.abs(dd)<.045&&(truthDrop<0||Math.abs(ed)<.045);if(!ok)bad++;
console.log((ok?'OK  ':'ERRO'),mode.padEnd(6),nome.padEnd(22),'bpm',a.bpm,'(erro '+eb.toFixed(3)+')','tempo1 erro',(dd*1000).toFixed(0)+' ms','virada erro',truthDrop>0?(ed*1000).toFixed(0)+' ms':'-','conf',a.conf)}
process.exit(bad?1:0);
