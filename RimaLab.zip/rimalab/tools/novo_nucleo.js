/* ===== player próprio (WebAudio) + análise automática. O relógio é o do áudio, então os pads não derivam ===== */
/*ANALYZER_INLINE*/
/* toca um AudioBuffer com a mesma interface do <audio> (currentTime, duration, play, pause). exact=1: posição exata, sem jitter */
class WAP{constructor(b){this.buf=b;this.duration=b.duration;this.off=0;this.src=null;this.t0=0;this.pl=false;this.exact=1;this.g=ctx.createGain();this.g.connect(ctx.destination);this.onplaying=this.onpause=this.onwaiting=this.onended=null}
get currentTime(){if(!this.pl)return this.off;return Math.max(0,Math.min(this.duration,this.off+ctx.currentTime-this.t0-(ctx.outputLatency||0)))}
set currentTime(v){v=Math.max(0,Math.min(this.duration-.05,v));const was=this.pl;if(was)this.stop();this.off=v;if(was)this.play()}
stop(){const s=this.src;this.src=null;this.pl=false;if(s){try{s.onended=null;s.stop()}catch(e){}try{s.disconnect()}catch(e){}}}
play(){if(this.pl)return Promise.resolve();try{ctx.resume&&ctx.resume()}catch(e){}const s=ctx.createBufferSource();s.buffer=this.buf;s.connect(this.g);const t=ctx.currentTime+.03;this.t0=t;s.start(t,this.off);this.src=s;this.pl=true;
s.onended=()=>{if(this.src===s){this.src=null;this.pl=false;this.off=0;this.onpause&&this.onpause();this.onended&&this.onended()}};this.onplaying&&this.onplaying();return Promise.resolve()}
pause(){if(!this.pl)return;const c=this.currentTime;this.stop();this.off=c;this.onpause&&this.onpause()}
kill(){this.stop();try{this.g.disconnect()}catch(e){}}}
const zMono=b=>{const n=b.length,o=new Float32Array(n),ch=b.numberOfChannels;for(let c=0;c<ch;c++){const d=b.getChannelData(c);for(let i=0;i<n;i++)o[i]+=d[i]/ch}return o};
const zSlug=s=>String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const ZMAN={};try{fetch('beats/manifest.json').then(r=>r.ok?r.json():{}).then(j=>Object.assign(ZMAN,j||{})).catch(()=>{})}catch(e){}
const zAnGet=(k,d)=>{let a=ZMAN[k];if(!a)try{a=JSON.parse(localStorage.getItem('an1_'+k)||'null')}catch(e){}return a&&a.bpm>0&&(!a.dur||Math.abs(a.dur-d)<.1)?a:null};
const zAnPut=(k,a,d)=>{try{localStorage.setItem('an1_'+k,JSON.stringify(Object.assign({dur:Math.round(d*100)/100},a)))}catch(e){}};
const zFlash=t=>{zMsg(t);setTimeout(()=>{if(zM==t)zMsg('')},2600)};
/* baixa o áudio, mede o beat (BPM exato, tempo 1, virada) e só então toca. ck=nome para guardar a medida (ou '') */
function zLocLoad(my,get,ck,hint,fall){ini();try{ctx.resume()}catch(e){}zMsg('Analisando o beat...');
get().then(ab=>ctx.decodeAudioData(ab)).then(buf=>{if(my!=zTok||!play)return;
const go=an=>{if(my!=zTok||!play)return;const a=zA=new WAP(buf);a.onplaying=()=>zSetPL(1);a.onpause=a.onwaiting=()=>zSetPL(0);a.onended=()=>zEnd(my);zGridSet(my,an);a.play();zBarUI()};
const ch=ck&&zAnGet(ck,buf.duration);if(ch){go(ch);return}
setTimeout(()=>{if(my!=zTok||!play)return;let an=null;try{an=rimaAnalyze(zMono(buf),buf.sampleRate,{hint:hint||0})}catch(e){}
if(!an)an={bpm:hint||90,g0:0,drop:-1};else if(ck)zAnPut(ck,an,buf.duration);go(an)},40)}).catch(()=>{if(my!=zTok)return;if(fall)fall();else zMsg('Não consegui abrir esse arquivo de áudio.')})}
/* aplica a medida: o compasso 1 de verdade, a virada e o BPM exato */
function zGridSet(my,an){if(my!=zTok||!ZS.dp)return;ZS.dp=0;const br=240/an.bpm,g0=an.g0;ZS.bpm=an.bpm;if(ZS.k=='file')ZS.b0=an.bpm;
const mn=g0+(PREB+1)*br;let td=an.drop>0?g0+Math.round((an.drop-g0)/br)*br:-1;const auto=!(td>=mn-1e-6);if(auto)td=mn;
ZS.dt=td;ZS.ph=td-br;zC=0;zBI=-1;zQ=-1;zPre=-1;zL=0;ZY.win=[];bpmUI();
zMsg(auto?'Sem introdução longa: o treino começa depois de '+PREB+(PREB>1?' compassos':' compasso')+' de beat.':'Virada do beat em '+(Math.round(td*10)/10)+' s (analisada do áudio).')}
