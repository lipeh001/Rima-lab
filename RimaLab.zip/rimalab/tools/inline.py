#!/usr/bin/env python3
"""Cola tools/analyzer.js dentro de rima-lab.html (entre /*ANALYZER_START*/ e /*ANALYZER_END*/). Rode de novo depois de mexer no analisador."""
import re,sys,os
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
html=os.path.join(root,'app/src/main/assets/rima-lab.html')
an=open(os.path.join(root,'tools/analyzer.js'),encoding='utf8').read()
code=an[an.index('/*ANALYZER_START*/'):an.index('/*ANALYZER_END*/')+len('/*ANALYZER_END*/')]
s=open(html,encoding='utf8').read()
if '/*ANALYZER_START*/' in s:
    s=s[:s.index('/*ANALYZER_START*/')]+code+s[s.index('/*ANALYZER_END*/')+len('/*ANALYZER_END*/'):]
elif '/*ANALYZER_INLINE*/' in s:
    s=s.replace('/*ANALYZER_INLINE*/',code)
else:
    sys.exit('marcador nao encontrado')
open(html,'w',encoding='utf8').write(s)
print('analisador colado no HTML')
