//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B-pc-j8y.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Cieb8_Hp.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cieb8_Hp.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Vq5dA8Gs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
