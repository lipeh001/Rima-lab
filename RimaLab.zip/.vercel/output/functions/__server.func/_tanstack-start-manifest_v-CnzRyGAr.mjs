//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CnzRyGAr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-I5xXYcnB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-I5xXYcnB.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CDLAYtoe.js"]
	}
} });
//#endregion
export { tsrStartManifest };
